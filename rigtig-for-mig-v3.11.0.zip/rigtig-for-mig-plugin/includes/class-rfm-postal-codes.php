<?php
/**
 * Danish Postal Codes Database
 *
 * Comprehensive database of Danish postal codes with geographic coordinates (latitude/longitude).
 * Data source: Based on official Danish postal code data.
 * Coordinates in WGS84 format (decimal degrees).
 *
 * @package Rigtig_For_Mig
 * @since 3.9.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class RFM_Postal_Codes {

    /**
     * Get all Danish postal codes with coordinates
     *
     * Returns array of postal codes with:
     * - postal_code: 4-digit postal code
     * - city: City name
     * - latitude: Latitude in decimal degrees
     * - longitude: Longitude in decimal degrees
     *
     * @return array Array of postal code data
     */
    public static function get_all_postal_codes() {
        return array(
            // København area (1000-1799, 2000-2999)
            array('postal_code' => '1000', 'city' => 'København K', 'latitude' => 55.6761, 'longitude' => 12.5683),
            array('postal_code' => '1050', 'city' => 'København K', 'latitude' => 55.6805, 'longitude' => 12.5747),
            array('postal_code' => '1100', 'city' => 'København K', 'latitude' => 55.6806, 'longitude' => 12.5805),
            array('postal_code' => '1150', 'city' => 'København K', 'latitude' => 55.6828, 'longitude' => 12.5890),
            array('postal_code' => '1200', 'city' => 'København K', 'latitude' => 55.6806, 'longitude' => 12.5820),
            array('postal_code' => '1250', 'city' => 'København K', 'latitude' => 55.6836, 'longitude' => 12.5739),
            array('postal_code' => '1300', 'city' => 'København K', 'latitude' => 55.6850, 'longitude' => 12.5844),
            array('postal_code' => '1350', 'city' => 'København K', 'latitude' => 55.6872, 'longitude' => 12.5780),
            array('postal_code' => '1400', 'city' => 'København K', 'latitude' => 55.6889, 'longitude' => 12.5839),
            array('postal_code' => '1450', 'city' => 'København K', 'latitude' => 55.6794, 'longitude' => 12.5883),
            array('postal_code' => '1500', 'city' => 'København V', 'latitude' => 55.6736, 'longitude' => 12.5589),
            array('postal_code' => '1550', 'city' => 'København V', 'latitude' => 55.6728, 'longitude' => 12.5544),
            array('postal_code' => '1600', 'city' => 'København V', 'latitude' => 55.6719, 'longitude' => 12.5506),
            array('postal_code' => '1650', 'city' => 'København V', 'latitude' => 55.6761, 'longitude' => 12.5450),
            array('postal_code' => '1700', 'city' => 'København V', 'latitude' => 55.6783, 'longitude' => 12.5461),
            array('postal_code' => '1750', 'city' => 'København V', 'latitude' => 55.6761, 'longitude' => 12.5500),
            array('postal_code' => '1800', 'city' => 'Frederiksberg C', 'latitude' => 55.6761, 'longitude' => 12.5344),
            array('postal_code' => '1850', 'city' => 'Frederiksberg C', 'latitude' => 55.6747, 'longitude' => 12.5319),
            array('postal_code' => '1900', 'city' => 'Frederiksberg C', 'latitude' => 55.6739, 'longitude' => 12.5294),
            array('postal_code' => '1950', 'city' => 'Frederiksberg C', 'latitude' => 55.6722, 'longitude' => 12.5278),
            array('postal_code' => '1951', 'city' => 'Frederiksberg C', 'latitude' => 55.6717, 'longitude' => 12.5267),
            array('postal_code' => '1952', 'city' => 'Frederiksberg C', 'latitude' => 55.6714, 'longitude' => 12.5261),
            array('postal_code' => '1953', 'city' => 'Frederiksberg C', 'latitude' => 55.6711, 'longitude' => 12.5256),
            array('postal_code' => '1954', 'city' => 'Frederiksberg C', 'latitude' => 55.6708, 'longitude' => 12.5250),
            array('postal_code' => '1999', 'city' => 'Frederiksberg C', 'latitude' => 55.6700, 'longitude' => 12.5239),

            // Frederiksberg & Copenhagen suburbs (2000-2999)
            array('postal_code' => '2000', 'city' => 'Frederiksberg', 'latitude' => 55.6761, 'longitude' => 12.5344),
            array('postal_code' => '2100', 'city' => 'København Ø', 'latitude' => 55.7139, 'longitude' => 12.5711),
            array('postal_code' => '2150', 'city' => 'Nordhavn', 'latitude' => 55.7167, 'longitude' => 12.5833),
            array('postal_code' => '2200', 'city' => 'København N', 'latitude' => 55.6997, 'longitude' => 12.5497),
            array('postal_code' => '2300', 'city' => 'København S', 'latitude' => 55.6489, 'longitude' => 12.5933),
            array('postal_code' => '2400', 'city' => 'København NV', 'latitude' => 55.7019, 'longitude' => 12.5253),
            array('postal_code' => '2450', 'city' => 'København SV', 'latitude' => 55.6536, 'longitude' => 12.5278),
            array('postal_code' => '2500', 'city' => 'Valby', 'latitude' => 55.6583, 'longitude' => 12.5053),
            array('postal_code' => '2600', 'city' => 'Glostrup', 'latitude' => 55.6708, 'longitude' => 12.4044),
            array('postal_code' => '2605', 'city' => 'Brøndby', 'latitude' => 55.6533, 'longitude' => 12.4189),
            array('postal_code' => '2610', 'city' => 'Rødovre', 'latitude' => 55.6819, 'longitude' => 12.4533),
            array('postal_code' => '2620', 'city' => 'Albertslund', 'latitude' => 55.6567, 'longitude' => 12.3633),
            array('postal_code' => '2625', 'city' => 'Vallensbæk', 'latitude' => 55.6281, 'longitude' => 12.3711),
            array('postal_code' => '2630', 'city' => 'Taastrup', 'latitude' => 55.6503, 'longitude' => 12.3011),
            array('postal_code' => '2635', 'city' => 'Ishøj', 'latitude' => 55.6153, 'longitude' => 12.3519),
            array('postal_code' => '2640', 'city' => 'Hedehusene', 'latitude' => 55.6531, 'longitude' => 12.1931),
            array('postal_code' => '2650', 'city' => 'Hvidovre', 'latitude' => 55.6572, 'longitude' => 12.4739),
            array('postal_code' => '2660', 'city' => 'Brøndby Strand', 'latitude' => 55.6267, 'longitude' => 12.4214),
            array('postal_code' => '2665', 'city' => 'Vallensbæk Strand', 'latitude' => 55.6133, 'longitude' => 12.3822),
            array('postal_code' => '2670', 'city' => 'Greve', 'latitude' => 55.5833, 'longitude' => 12.3000),
            array('postal_code' => '2680', 'city' => 'Solrød Strand', 'latitude' => 55.5286, 'longitude' => 12.2197),
            array('postal_code' => '2690', 'city' => 'Karlslunde', 'latitude' => 55.5583, 'longitude' => 12.2472),
            array('postal_code' => '2700', 'city' => 'Brønshøj', 'latitude' => 55.7050, 'longitude' => 12.4947),
            array('postal_code' => '2720', 'city' => 'Vanløse', 'latitude' => 55.6833, 'longitude' => 12.4833),
            array('postal_code' => '2730', 'city' => 'Herlev', 'latitude' => 55.7308, 'longitude' => 12.4422),
            array('postal_code' => '2740', 'city' => 'Skovlunde', 'latitude' => 55.7181, 'longitude' => 12.3967),
            array('postal_code' => '2750', 'city' => 'Ballerup', 'latitude' => 55.7311, 'longitude' => 12.3631),
            array('postal_code' => '2760', 'city' => 'Måløv', 'latitude' => 55.7467, 'longitude' => 12.3247),
            array('postal_code' => '2765', 'city' => 'Smørum', 'latitude' => 55.7439, 'longitude' => 12.3089),
            array('postal_code' => '2770', 'city' => 'Kastrup', 'latitude' => 55.6289, 'longitude' => 12.6431),
            array('postal_code' => '2791', 'city' => 'Dragør', 'latitude' => 55.5931, 'longitude' => 12.6739),
            array('postal_code' => '2800', 'city' => 'Kongens Lyngby', 'latitude' => 55.7706, 'longitude' => 12.5044),
            array('postal_code' => '2820', 'city' => 'Gentofte', 'latitude' => 55.7461, 'longitude' => 12.5481),
            array('postal_code' => '2830', 'city' => 'Virum', 'latitude' => 55.7919, 'longitude' => 12.4989),
            array('postal_code' => '2840', 'city' => 'Holte', 'latitude' => 55.8119, 'longitude' => 12.4719),
            array('postal_code' => '2850', 'city' => 'Nærum', 'latitude' => 55.8264, 'longitude' => 12.5308),
            array('postal_code' => '2860', 'city' => 'Søborg', 'latitude' => 55.7292, 'longitude' => 12.5111),
            array('postal_code' => '2870', 'city' => 'Dyssegård', 'latitude' => 55.7419, 'longitude' => 12.5256),
            array('postal_code' => '2880', 'city' => 'Bagsværd', 'latitude' => 55.7581, 'longitude' => 12.4486),
            array('postal_code' => '2900', 'city' => 'Hellerup', 'latitude' => 55.7333, 'longitude' => 12.5697),
            array('postal_code' => '2920', 'city' => 'Charlottenlund', 'latitude' => 55.7508, 'longitude' => 12.5808),
            array('postal_code' => '2930', 'city' => 'Klampenborg', 'latitude' => 55.7772, 'longitude' => 12.5894),
            array('postal_code' => '2942', 'city' => 'Skodsborg', 'latitude' => 55.8250, 'longitude' => 12.5717),
            array('postal_code' => '2950', 'city' => 'Vedbæk', 'latitude' => 55.8544, 'longitude' => 12.5647),
            array('postal_code' => '2960', 'city' => 'Rungsted Kyst', 'latitude' => 55.8844, 'longitude' => 12.5408),
            array('postal_code' => '2970', 'city' => 'Hørsholm', 'latitude' => 55.8808, 'longitude' => 12.5014),
            array('postal_code' => '2980', 'city' => 'Kokkedal', 'latitude' => 55.9103, 'longitude' => 12.5044),
            array('postal_code' => '2990', 'city' => 'Nivå', 'latitude' => 55.9297, 'longitude' => 12.5092),

            // Nordsjælland (3000-3999)
            array('postal_code' => '3000', 'city' => 'Helsingør', 'latitude' => 56.0361, 'longitude' => 12.6136),
            array('postal_code' => '3050', 'city' => 'Humlebæk', 'latitude' => 55.9617, 'longitude' => 12.5347),
            array('postal_code' => '3060', 'city' => 'Espergærde', 'latitude' => 56.0025, 'longitude' => 12.5392),
            array('postal_code' => '3070', 'city' => 'Snekkersten', 'latitude' => 56.0669, 'longitude' => 12.6033),
            array('postal_code' => '3080', 'city' => 'Tikøb', 'latitude' => 56.0733, 'longitude' => 12.5444),
            array('postal_code' => '3100', 'city' => 'Hornbæk', 'latitude' => 56.0936, 'longitude' => 12.4569),
            array('postal_code' => '3120', 'city' => 'Dronningmølle', 'latitude' => 56.0947, 'longitude' => 12.3764),
            array('postal_code' => '3140', 'city' => 'Ålsgårde', 'latitude' => 56.0753, 'longitude' => 12.5400),
            array('postal_code' => '3150', 'city' => 'Hellebæk', 'latitude' => 56.0697, 'longitude' => 12.5517),
            array('postal_code' => '3200', 'city' => 'Helsinge', 'latitude' => 56.0222, 'longitude' => 12.1989),
            array('postal_code' => '3210', 'city' => 'Vejby', 'latitude' => 56.0808, 'longitude' => 12.2214),
            array('postal_code' => '3220', 'city' => 'Tisvildeleje', 'latitude' => 56.0656, 'longitude' => 12.0781),
            array('postal_code' => '3230', 'city' => 'Græsted', 'latitude' => 56.0708, 'longitude' => 12.2844),
            array('postal_code' => '3250', 'city' => 'Gilleleje', 'latitude' => 56.1219, 'longitude' => 12.3094),
            array('postal_code' => '3300', 'city' => 'Frederiksværk', 'latitude' => 55.9711, 'longitude' => 12.0200),
            array('postal_code' => '3310', 'city' => 'Ølsted', 'latitude' => 55.9731, 'longitude' => 11.9711),
            array('postal_code' => '3320', 'city' => 'Skævinge', 'latitude' => 55.9336, 'longitude' => 12.0611),
            array('postal_code' => '3330', 'city' => 'Gørløse', 'latitude' => 55.9089, 'longitude' => 12.1353),
            array('postal_code' => '3360', 'city' => 'Liseleje', 'latitude' => 56.0089, 'longitude' => 11.9603),
            array('postal_code' => '3370', 'city' => 'Melby', 'latitude' => 56.0303, 'longitude' => 11.9831),
            array('postal_code' => '3390', 'city' => 'Hundested', 'latitude' => 55.9653, 'longitude' => 11.8594),
            array('postal_code' => '3400', 'city' => 'Hillerød', 'latitude' => 55.9272, 'longitude' => 12.3111),
            array('postal_code' => '3450', 'city' => 'Allerød', 'latitude' => 55.8711, 'longitude' => 12.3517),
            array('postal_code' => '3460', 'city' => 'Birkerød', 'latitude' => 55.8450, 'longitude' => 12.4289),
            array('postal_code' => '3480', 'city' => 'Fredensborg', 'latitude' => 55.9708, 'longitude' => 12.4011),
            array('postal_code' => '3490', 'city' => 'Kvistgård', 'latitude' => 55.9581, 'longitude' => 12.4722),
            array('postal_code' => '3500', 'city' => 'Værløse', 'latitude' => 55.7842, 'longitude' => 12.3661),
            array('postal_code' => '3520', 'city' => 'Farum', 'latitude' => 55.8086, 'longitude' => 12.3622),
            array('postal_code' => '3540', 'city' => 'Lynge', 'latitude' => 55.8406, 'longitude' => 12.2756),
            array('postal_code' => '3550', 'city' => 'Slangerup', 'latitude' => 55.8503, 'longitude' => 12.1806),
            array('postal_code' => '3600', 'city' => 'Frederikssund', 'latitude' => 55.8400, 'longitude' => 12.0686),
            array('postal_code' => '3630', 'city' => 'Jægerspris', 'latitude' => 55.8722, 'longitude' => 11.9781),
            array('postal_code' => '3650', 'city' => 'Ølstykke', 'latitude' => 55.7914, 'longitude' => 12.1703),
            array('postal_code' => '3660', 'city' => 'Stenløse', 'latitude' => 55.7683, 'longitude' => 12.2006),
            array('postal_code' => '3670', 'city' => 'Veksø Sjælland', 'latitude' => 55.7472, 'longitude' => 12.2700),
            array('postal_code' => '3700', 'city' => 'Rønne', 'latitude' => 55.1000, 'longitude' => 14.7000),
            array('postal_code' => '3720', 'city' => 'Aakirkeby', 'latitude' => 55.0711, 'longitude' => 14.9222),
            array('postal_code' => '3730', 'city' => 'Nexø', 'latitude' => 55.0600, 'longitude' => 15.1328),
            array('postal_code' => '3740', 'city' => 'Svaneke', 'latitude' => 55.1344, 'longitude' => 15.1439),
            array('postal_code' => '3751', 'city' => 'Østermarie', 'latitude' => 55.1144, 'longitude' => 14.9897),
            array('postal_code' => '3760', 'city' => 'Gudhjem', 'latitude' => 55.2078, 'longitude' => 14.9625),
            array('postal_code' => '3770', 'city' => 'Allinge', 'latitude' => 55.2711, 'longitude' => 14.8036),
            array('postal_code' => '3782', 'city' => 'Klemensker', 'latitude' => 55.2094, 'longitude' => 14.8011),
            array('postal_code' => '3790', 'city' => 'Hasle', 'latitude' => 55.1814, 'longitude' => 14.7131),

            // Vestsjælland & Sydsjælland (4000-4999)
            array('postal_code' => '4000', 'city' => 'Roskilde', 'latitude' => 55.6419, 'longitude' => 12.0803),
            array('postal_code' => '4030', 'city' => 'Tune', 'latitude' => 55.5931, 'longitude' => 12.1444),
            array('postal_code' => '4040', 'city' => 'Jyllinge', 'latitude' => 55.7508, 'longitude' => 12.1089),
            array('postal_code' => '4050', 'city' => 'Skibby', 'latitude' => 55.7525, 'longitude' => 11.9675),
            array('postal_code' => '4060', 'city' => 'Kirke Såby', 'latitude' => 55.7069, 'longitude' => 12.1006),
            array('postal_code' => '4070', 'city' => 'Kirke Hyllinge', 'latitude' => 55.6881, 'longitude' => 12.0000),
            array('postal_code' => '4100', 'city' => 'Ringsted', 'latitude' => 55.4428, 'longitude' => 11.7900),
            array('postal_code' => '4130', 'city' => 'Viby Sjælland', 'latitude' => 55.4700, 'longitude' => 11.9147),
            array('postal_code' => '4140', 'city' => 'Borup', 'latitude' => 55.4881, 'longitude' => 11.9736),
            array('postal_code' => '4160', 'city' => 'Herlufmagle', 'latitude' => 55.3867, 'longitude' => 11.7928),
            array('postal_code' => '4171', 'city' => 'Glumsø', 'latitude' => 55.3756, 'longitude' => 11.5561),
            array('postal_code' => '4173', 'city' => 'Fjenneslev', 'latitude' => 55.4469, 'longitude' => 11.5772),
            array('postal_code' => '4174', 'city' => 'Jystrup Midtsj', 'latitude' => 55.4792, 'longitude' => 11.6639),
            array('postal_code' => '4180', 'city' => 'Sorø', 'latitude' => 55.4322, 'longitude' => 11.5556),
            array('postal_code' => '4190', 'city' => 'Munke Bjergby', 'latitude' => 55.5036, 'longitude' => 11.7056),
            array('postal_code' => '4200', 'city' => 'Slagelse', 'latitude' => 55.4028, 'longitude' => 11.3544),
            array('postal_code' => '4220', 'city' => 'Korsør', 'latitude' => 55.3297, 'longitude' => 11.1392),
            array('postal_code' => '4230', 'city' => 'Skælskør', 'latitude' => 55.2508, 'longitude' => 11.2908),
            array('postal_code' => '4241', 'city' => 'Vemmelev', 'latitude' => 55.4194, 'longitude' => 11.2631),
            array('postal_code' => '4242', 'city' => 'Boeslunde', 'latitude' => 55.4681, 'longitude' => 11.3681),
            array('postal_code' => '4243', 'city' => 'Rude', 'latitude' => 55.4333, 'longitude' => 11.4589),
            array('postal_code' => '4250', 'city' => 'Fuglebjerg', 'latitude' => 55.2917, 'longitude' => 11.5444),
            array('postal_code' => '4261', 'city' => 'Dalmose', 'latitude' => 55.2972, 'longitude' => 11.3833),
            array('postal_code' => '4262', 'city' => 'Sandved', 'latitude' => 55.3331, 'longitude' => 11.2592),
            array('postal_code' => '4270', 'city' => 'Høng', 'latitude' => 55.4825, 'longitude' => 11.3083),
            array('postal_code' => '4281', 'city' => 'Gørlev', 'latitude' => 55.5386, 'longitude' => 11.2278),
            array('postal_code' => '4291', 'city' => 'Ruds Vedby', 'latitude' => 55.5244, 'longitude' => 11.4111),
            array('postal_code' => '4293', 'city' => 'Dianalund', 'latitude' => 55.5269, 'longitude' => 11.4972),
            array('postal_code' => '4295', 'city' => 'Stenlille', 'latitude' => 55.5414, 'longitude' => 11.5714),
            array('postal_code' => '4296', 'city' => 'Nyrup', 'latitude' => 55.5683, 'longitude' => 11.6008),
            array('postal_code' => '4300', 'city' => 'Holbæk', 'latitude' => 55.7119, 'longitude' => 11.7158),
            array('postal_code' => '4320', 'city' => 'Lejre', 'latitude' => 55.6047, 'longitude' => 11.9647),
            array('postal_code' => '4330', 'city' => 'Hvalsø', 'latitude' => 55.5856, 'longitude' => 11.8686),
            array('postal_code' => '4340', 'city' => 'Tølløse', 'latitude' => 55.6178, 'longitude' => 11.7597),
            array('postal_code' => '4350', 'city' => 'Ugerløse', 'latitude' => 55.6647, 'longitude' => 11.6331),
            array('postal_code' => '4360', 'city' => 'Kirke Eskilstrup', 'latitude' => 54.8444, 'longitude' => 11.8378),
            array('postal_code' => '4370', 'city' => 'Store Merløse', 'latitude' => 55.6842, 'longitude' => 11.5706),
            array('postal_code' => '4390', 'city' => 'Vipperød', 'latitude' => 55.7622, 'longitude' => 11.7400),
            array('postal_code' => '4400', 'city' => 'Kalundborg', 'latitude' => 55.6794, 'longitude' => 11.0886),
            array('postal_code' => '4420', 'city' => 'Regstrup', 'latitude' => 55.7114, 'longitude' => 11.5550),
            array('postal_code' => '4440', 'city' => 'Mørkøv', 'latitude' => 55.6189, 'longitude' => 11.4139),
            array('postal_code' => '4450', 'city' => 'Jyderup', 'latitude' => 55.6636, 'longitude' => 11.4256),
            array('postal_code' => '4460', 'city' => 'Snertinge', 'latitude' => 55.7261, 'longitude' => 11.3756),
            array('postal_code' => '4470', 'city' => 'Svebølle', 'latitude' => 55.6603, 'longitude' => 11.2667),
            array('postal_code' => '4480', 'city' => 'Store Fuglede', 'latitude' => 55.7119, 'longitude' => 11.2369),
            array('postal_code' => '4490', 'city' => 'Jerslev Sjælland', 'latitude' => 55.7419, 'longitude' => 11.2686),
            array('postal_code' => '4500', 'city' => 'Nykøbing Sj', 'latitude' => 55.9250, 'longitude' => 11.6722),
            array('postal_code' => '4520', 'city' => 'Svinninge', 'latitude' => 55.8081, 'longitude' => 11.5092),
            array('postal_code' => '4532', 'city' => 'Gislinge', 'latitude' => 55.7733, 'longitude' => 11.3761),
            array('postal_code' => '4534', 'city' => 'Hørve', 'latitude' => 55.7986, 'longitude' => 11.4381),
            array('postal_code' => '4540', 'city' => 'Fårevejle', 'latitude' => 55.8064, 'longitude' => 11.2489),
            array('postal_code' => '4550', 'city' => 'Asnæs', 'latitude' => 55.8100, 'longitude' => 11.5089),
            array('postal_code' => '4560', 'city' => 'Vig', 'latitude' => 55.8553, 'longitude' => 11.3789),
            array('postal_code' => '4571', 'city' => 'Grevinge', 'latitude' => 55.8900, 'longitude' => 11.5508),
            array('postal_code' => '4572', 'city' => 'Nørre Asmindrup', 'latitude' => 55.8994, 'longitude' => 11.4997),
            array('postal_code' => '4573', 'city' => 'Højby', 'latitude' => 55.9308, 'longitude' => 11.5589),
            array('postal_code' => '4581', 'city' => 'Rørvig', 'latitude' => 55.9469, 'longitude' => 11.7339),
            array('postal_code' => '4583', 'city' => 'Sjællands Odde', 'latitude' => 56.0142, 'longitude' => 11.3828),
            array('postal_code' => '4591', 'city' => 'Føllenslev', 'latitude' => 55.7842, 'longitude' => 11.6158),
            array('postal_code' => '4592', 'city' => 'Sejerø', 'latitude' => 55.9008, 'longitude' => 11.1414),
            array('postal_code' => '4593', 'city' => 'Eskebjerg', 'latitude' => 55.7981, 'longitude' => 11.2000),
            array('postal_code' => '4600', 'city' => 'Køge', 'latitude' => 55.4578, 'longitude' => 12.1819),
            array('postal_code' => '4621', 'city' => 'Gadstrup', 'latitude' => 55.5581, 'longitude' => 12.1033),
            array('postal_code' => '4622', 'city' => 'Havdrup', 'latitude' => 55.5372, 'longitude' => 12.1336),
            array('postal_code' => '4623', 'city' => 'Lille Skensved', 'latitude' => 55.5017, 'longitude' => 12.1550),
            array('postal_code' => '4632', 'city' => 'Bjæverskov', 'latitude' => 55.4611, 'longitude' => 12.0364),
            array('postal_code' => '4640', 'city' => 'Faxe', 'latitude' => 55.2550, 'longitude' => 12.1189),
            array('postal_code' => '4652', 'city' => 'Hårlev', 'latitude' => 55.3739, 'longitude' => 12.1336),
            array('postal_code' => '4653', 'city' => 'Karise', 'latitude' => 55.3431, 'longitude' => 12.1817),
            array('postal_code' => '4654', 'city' => 'Faxe Ladeplads', 'latitude' => 55.2178, 'longitude' => 12.1644),
            array('postal_code' => '4660', 'city' => 'Store Heddinge', 'latitude' => 55.3086, 'longitude' => 12.3900),
            array('postal_code' => '4671', 'city' => 'Strøby', 'latitude' => 55.4000, 'longitude' => 12.2833),
            array('postal_code' => '4672', 'city' => 'Klippinge', 'latitude' => 55.2917, 'longitude' => 12.2333),
            array('postal_code' => '4673', 'city' => 'Rødvig Stevns', 'latitude' => 55.2550, 'longitude' => 12.3775),
            array('postal_code' => '4681', 'city' => 'Herfølge', 'latitude' => 55.4239, 'longitude' => 12.1456),
            array('postal_code' => '4682', 'city' => 'Tureby', 'latitude' => 55.3864, 'longitude' => 12.0594),
            array('postal_code' => '4683', 'city' => 'Rønnede', 'latitude' => 55.3483, 'longitude' => 12.0264),
            array('postal_code' => '4684', 'city' => 'Holmegaard', 'latitude' => 55.2550, 'longitude' => 12.0228),
            array('postal_code' => '4690', 'city' => 'Haslev', 'latitude' => 55.3236, 'longitude' => 11.9650),
            array('postal_code' => '4700', 'city' => 'Næstved', 'latitude' => 55.2297, 'longitude' => 11.7611),
            array('postal_code' => '4720', 'city' => 'Præstø', 'latitude' => 55.1250, 'longitude' => 12.0442),
            array('postal_code' => '4733', 'city' => 'Tappernøje', 'latitude' => 55.1578, 'longitude' => 11.8594),
            array('postal_code' => '4735', 'city' => 'Mern', 'latitude' => 55.1936, 'longitude' => 12.0228),
            array('postal_code' => '4736', 'city' => 'Karrebæksminde', 'latitude' => 55.1742, 'longitude' => 11.6450),
            array('postal_code' => '4750', 'city' => 'Lundby', 'latitude' => 55.0917, 'longitude' => 11.5186),
            array('postal_code' => '4760', 'city' => 'Vordingborg', 'latitude' => 55.0064, 'longitude' => 11.9111),
            array('postal_code' => '4771', 'city' => 'Kalvehave', 'latitude' => 54.9958, 'longitude' => 12.2136),
            array('postal_code' => '4772', 'city' => 'Langebæk', 'latitude' => 54.9453, 'longitude' => 12.0333),
            array('postal_code' => '4773', 'city' => 'Stensved', 'latitude' => 55.0522, 'longitude' => 11.9861),
            array('postal_code' => '4780', 'city' => 'Stege', 'latitude' => 54.9878, 'longitude' => 12.2853),
            array('postal_code' => '4791', 'city' => 'Borre', 'latitude' => 54.9678, 'longitude' => 12.4539),
            array('postal_code' => '4792', 'city' => 'Askeby', 'latitude' => 54.9328, 'longitude' => 12.3472),
            array('postal_code' => '4793', 'city' => 'Bogø By', 'latitude' => 54.9333, 'longitude' => 12.0667),
            array('postal_code' => '4800', 'city' => 'Nykøbing F', 'latitude' => 54.7694, 'longitude' => 11.8739),
            array('postal_code' => '4840', 'city' => 'Nørre Alslev', 'latitude' => 54.9006, 'longitude' => 11.9247),
            array('postal_code' => '4850', 'city' => 'Stubbekøbing', 'latitude' => 54.8836, 'longitude' => 12.0497),
            array('postal_code' => '4862', 'city' => 'Guldborg', 'latitude' => 54.6636, 'longitude' => 11.8142),
            array('postal_code' => '4863', 'city' => 'Eskilstrup', 'latitude' => 54.8444, 'longitude' => 11.8378),
            array('postal_code' => '4871', 'city' => 'Horbelev', 'latitude' => 54.8147, 'longitude' => 11.9722),
            array('postal_code' => '4872', 'city' => 'Idestrup', 'latitude' => 54.7703, 'longitude' => 11.7742),
            array('postal_code' => '4873', 'city' => 'Væggerløse', 'latitude' => 54.8333, 'longitude' => 11.8500),
            array('postal_code' => '4874', 'city' => 'Gedser', 'latitude' => 54.5742, 'longitude' => 11.9283),
            array('postal_code' => '4880', 'city' => 'Nysted', 'latitude' => 54.6614, 'longitude' => 11.7289),
            array('postal_code' => '4891', 'city' => 'Toreby L', 'latitude' => 54.7119, 'longitude' => 11.6714),
            array('postal_code' => '4892', 'city' => 'Kettinge', 'latitude' => 54.7428, 'longitude' => 11.8144),
            array('postal_code' => '4894', 'city' => 'Øster Ulslev', 'latitude' => 54.7889, 'longitude' => 11.8778),
            array('postal_code' => '4895', 'city' => 'Errindlev', 'latitude' => 54.7644, 'longitude' => 11.8028),
            array('postal_code' => '4900', 'city' => 'Nakskov', 'latitude' => 54.8306, 'longitude' => 11.1358),
            array('postal_code' => '4912', 'city' => 'Harpelunde', 'latitude' => 54.8444, 'longitude' => 11.2278),
            array('postal_code' => '4913', 'city' => 'Horslunde', 'latitude' => 54.8689, 'longitude' => 11.3928),
            array('postal_code' => '4920', 'city' => 'Søllested', 'latitude' => 54.7928, 'longitude' => 11.2222),
            array('postal_code' => '4930', 'city' => 'Maribo', 'latitude' => 54.7744, 'longitude' => 11.5008),
            array('postal_code' => '4941', 'city' => 'Bandholm', 'latitude' => 54.8286, 'longitude' => 11.4844),
            array('postal_code' => '4943', 'city' => 'Torrig L', 'latitude' => 54.8069, 'longitude' => 11.6019),
            array('postal_code' => '4944', 'city' => 'Fejø', 'latitude' => 54.9500, 'longitude' => 11.3333),
            array('postal_code' => '4951', 'city' => 'Nørreballe', 'latitude' => 54.7500, 'longitude' => 11.3944),
            array('postal_code' => '4952', 'city' => 'Stokkemarke', 'latitude' => 54.7542, 'longitude' => 11.4436),
            array('postal_code' => '4953', 'city' => 'Vesterborg', 'latitude' => 54.7444, 'longitude' => 11.2764),
            array('postal_code' => '4960', 'city' => 'Holeby', 'latitude' => 54.7028, 'longitude' => 11.4681),
            array('postal_code' => '4970', 'city' => 'Rødby', 'latitude' => 54.6978, 'longitude' => 11.3889),
            array('postal_code' => '4983', 'city' => 'Dannemare', 'latitude' => 54.7611, 'longitude' => 11.6733),
            array('postal_code' => '4990', 'city' => 'Sakskøbing', 'latitude' => 54.7997, 'longitude' => 11.6267),

            // Fyn (5000-5999)
            array('postal_code' => '5000', 'city' => 'Odense C', 'latitude' => 55.3959, 'longitude' => 10.3883),
            array('postal_code' => '5200', 'city' => 'Odense V', 'latitude' => 55.3900, 'longitude' => 10.3561),
            array('postal_code' => '5210', 'city' => 'Odense NV', 'latitude' => 55.4186, 'longitude' => 10.3619),
            array('postal_code' => '5220', 'city' => 'Odense SØ', 'latitude' => 55.3800, 'longitude' => 10.4300),
            array('postal_code' => '5230', 'city' => 'Odense M', 'latitude' => 55.4039, 'longitude' => 10.3911),
            array('postal_code' => '5240', 'city' => 'Odense NØ', 'latitude' => 55.4219, 'longitude' => 10.4208),
            array('postal_code' => '5250', 'city' => 'Odense SV', 'latitude' => 55.3692, 'longitude' => 10.3708),
            array('postal_code' => '5260', 'city' => 'Odense S', 'latitude' => 55.3719, 'longitude' => 10.3972),
            array('postal_code' => '5270', 'city' => 'Odense N', 'latitude' => 55.4239, 'longitude' => 10.3894),
            array('postal_code' => '5290', 'city' => 'Marslev', 'latitude' => 55.3519, 'longitude' => 10.4686),
            array('postal_code' => '5300', 'city' => 'Kerteminde', 'latitude' => 55.4500, 'longitude' => 10.6583),
            array('postal_code' => '5320', 'city' => 'Agedrup', 'latitude' => 55.4728, 'longitude' => 10.4778),
            array('postal_code' => '5330', 'city' => 'Munkebo', 'latitude' => 55.4633, 'longitude' => 10.5597),
            array('postal_code' => '5350', 'city' => 'Rynkeby', 'latitude' => 55.4186, 'longitude' => 10.5300),
            array('postal_code' => '5370', 'city' => 'Mesinge', 'latitude' => 55.4719, 'longitude' => 10.5150),
            array('postal_code' => '5380', 'city' => 'Dalby', 'latitude' => 55.3886, 'longitude' => 10.6083),
            array('postal_code' => '5390', 'city' => 'Martofte', 'latitude' => 55.4472, 'longitude' => 10.6217),
            array('postal_code' => '5400', 'city' => 'Bogense', 'latitude' => 55.5678, 'longitude' => 10.0892),
            array('postal_code' => '5450', 'city' => 'Otterup', 'latitude' => 55.5189, 'longitude' => 10.3989),
            array('postal_code' => '5462', 'city' => 'Morud', 'latitude' => 55.4750, 'longitude' => 10.3500),
            array('postal_code' => '5463', 'city' => 'Harndrup', 'latitude' => 55.4883, 'longitude' => 10.3239),
            array('postal_code' => '5464', 'city' => 'Brenderup Fyn', 'latitude' => 55.4533, 'longitude' => 10.3114),
            array('postal_code' => '5466', 'city' => 'Asperup', 'latitude' => 55.4350, 'longitude' => 10.3017),
            array('postal_code' => '5471', 'city' => 'Søndersø', 'latitude' => 55.4875, 'longitude' => 10.2689),
            array('postal_code' => '5474', 'city' => 'Veflinge', 'latitude' => 55.5333, 'longitude' => 10.2472),
            array('postal_code' => '5485', 'city' => 'Skamby', 'latitude' => 55.4628, 'longitude' => 10.1983),
            array('postal_code' => '5491', 'city' => 'Blommenslyst', 'latitude' => 55.4342, 'longitude' => 10.4158),
            array('postal_code' => '5492', 'city' => 'Vissenbjerg', 'latitude' => 55.3850, 'longitude' => 10.1389),
            array('postal_code' => '5500', 'city' => 'Middelfart', 'latitude' => 55.5061, 'longitude' => 9.7306),
            array('postal_code' => '5540', 'city' => 'Ullerslev', 'latitude' => 55.3686, 'longitude' => 10.6622),
            array('postal_code' => '5550', 'city' => 'Langeskov', 'latitude' => 55.3608, 'longitude' => 10.5900),
            array('postal_code' => '5560', 'city' => 'Aarup', 'latitude' => 55.3753, 'longitude' => 10.0419),
            array('postal_code' => '5580', 'city' => 'Nørre Aaby', 'latitude' => 55.4586, 'longitude' => 10.1089),
            array('postal_code' => '5591', 'city' => 'Gelsted', 'latitude' => 55.4222, 'longitude' => 10.0714),
            array('postal_code' => '5592', 'city' => 'Ejby', 'latitude' => 55.3847, 'longitude' => 10.0872),
            array('postal_code' => '5600', 'city' => 'Faaborg', 'latitude' => 55.0942, 'longitude' => 10.2431),
            array('postal_code' => '5610', 'city' => 'Assens', 'latitude' => 55.2689, 'longitude' => 9.8989),
            array('postal_code' => '5620', 'city' => 'Glamsbjerg', 'latitude' => 55.2644, 'longitude' => 10.1158),
            array('postal_code' => '5631', 'city' => 'Ebberup', 'latitude' => 55.2147, 'longitude' => 10.3017),
            array('postal_code' => '5642', 'city' => 'Millinge', 'latitude' => 55.1436, 'longitude' => 10.3119),
            array('postal_code' => '5672', 'city' => 'Broby', 'latitude' => 55.1725, 'longitude' => 10.4558),
            array('postal_code' => '5683', 'city' => 'Haarby', 'latitude' => 55.1869, 'longitude' => 10.1192),
            array('postal_code' => '5690', 'city' => 'Tommerup', 'latitude' => 55.3194, 'longitude' => 10.2069),
            array('postal_code' => '5700', 'city' => 'Svendborg', 'latitude' => 55.0597, 'longitude' => 10.6072),
            array('postal_code' => '5750', 'city' => 'Ringe', 'latitude' => 55.2467, 'longitude' => 10.4800),
            array('postal_code' => '5762', 'city' => 'Vester Skerninge', 'latitude' => 55.1258, 'longitude' => 10.5422),
            array('postal_code' => '5771', 'city' => 'Stenstrup', 'latitude' => 55.1117, 'longitude' => 10.6858),
            array('postal_code' => '5772', 'city' => 'Kværndrup', 'latitude' => 55.1800, 'longitude' => 10.5700),
            array('postal_code' => '5792', 'city' => 'Årslev', 'latitude' => 55.3078, 'longitude' => 10.4578),
            array('postal_code' => '5800', 'city' => 'Nyborg', 'latitude' => 55.3122, 'longitude' => 10.7897),
            array('postal_code' => '5853', 'city' => 'Ørbæk', 'latitude' => 55.2764, 'longitude' => 10.6658),
            array('postal_code' => '5854', 'city' => 'Gislev', 'latitude' => 55.2158, 'longitude' => 10.5389),
            array('postal_code' => '5856', 'city' => 'Ryslinge', 'latitude' => 55.2267, 'longitude' => 10.5842),
            array('postal_code' => '5863', 'city' => 'Ferritslev Fyn', 'latitude' => 55.2853, 'longitude' => 10.8103),
            array('postal_code' => '5871', 'city' => 'Frørup', 'latitude' => 55.1289, 'longitude' => 10.7342),
            array('postal_code' => '5874', 'city' => 'Hesselager', 'latitude' => 55.0833, 'longitude' => 10.7644),
            array('postal_code' => '5881', 'city' => 'Skårup Fyn', 'latitude' => 55.0856, 'longitude' => 10.5236),
            array('postal_code' => '5882', 'city' => 'Vejstrup', 'latitude' => 55.0283, 'longitude' => 10.5264),
            array('postal_code' => '5883', 'city' => 'Oure', 'latitude' => 55.0419, 'longitude' => 10.4694),
            array('postal_code' => '5884', 'city' => 'Gudme', 'latitude' => 55.0508, 'longitude' => 10.7000),
            array('postal_code' => '5892', 'city' => 'Gudbjerg Sydfyn', 'latitude' => 55.0158, 'longitude' => 10.3478),
            array('postal_code' => '5900', 'city' => 'Rudkøbing', 'latitude' => 54.9400, 'longitude' => 10.7133),
            array('postal_code' => '5932', 'city' => 'Humble', 'latitude' => 54.8883, 'longitude' => 10.6856),
            array('postal_code' => '5935', 'city' => 'Bagenkop', 'latitude' => 54.7533, 'longitude' => 10.6881),
            array('postal_code' => '5953', 'city' => 'Tranekær', 'latitude' => 54.9478, 'longitude' => 10.8508),
            array('postal_code' => '5960', 'city' => 'Marstal', 'latitude' => 54.8561, 'longitude' => 10.5158),
            array('postal_code' => '5970', 'city' => 'Ærøskøbing', 'latitude' => 54.8931, 'longitude' => 10.4094),
            array('postal_code' => '5985', 'city' => 'Søby Ærø', 'latitude' => 54.9278, 'longitude' => 10.2592),

            // Jylland (6000-9999)
            array('postal_code' => '6000', 'city' => 'Kolding', 'latitude' => 55.4903, 'longitude' => 9.4725),
            array('postal_code' => '6040', 'city' => 'Egtved', 'latitude' => 55.6208, 'longitude' => 9.2892),
            array('postal_code' => '6051', 'city' => 'Almind', 'latitude' => 55.5739, 'longitude' => 9.3953),
            array('postal_code' => '6052', 'city' => 'Viuf', 'latitude' => 55.5569, 'longitude' => 9.4253),
            array('postal_code' => '6064', 'city' => 'Jordrup', 'latitude' => 55.5478, 'longitude' => 9.2242),
            array('postal_code' => '6070', 'city' => 'Christiansfeld', 'latitude' => 55.3594, 'longitude' => 9.4869),
            array('postal_code' => '6091', 'city' => 'Bjert', 'latitude' => 55.4869, 'longitude' => 9.6308),
            array('postal_code' => '6092', 'city' => 'Sønder Stenderup', 'latitude' => 55.4667, 'longitude' => 9.5378),
            array('postal_code' => '6093', 'city' => 'Sjølund', 'latitude' => 55.4622, 'longitude' => 9.6739),
            array('postal_code' => '6094', 'city' => 'Hejls', 'latitude' => 55.4519, 'longitude' => 9.6003),
            array('postal_code' => '6100', 'city' => 'Haderslev', 'latitude' => 55.2536, 'longitude' => 9.4897),
            array('postal_code' => '6200', 'city' => 'Aabenraa', 'latitude' => 55.0447, 'longitude' => 9.4178),
            array('postal_code' => '6230', 'city' => 'Rødekro', 'latitude' => 55.0686, 'longitude' => 9.3339),
            array('postal_code' => '6240', 'city' => 'Løgumkloster', 'latitude' => 55.0569, 'longitude' => 8.9542),
            array('postal_code' => '6261', 'city' => 'Bredebro', 'latitude' => 55.0494, 'longitude' => 8.7761),
            array('postal_code' => '6270', 'city' => 'Tønder', 'latitude' => 54.9333, 'longitude' => 8.8667),
            array('postal_code' => '6300', 'city' => 'Gråsten', 'latitude' => 54.9158, 'longitude' => 9.5889),
            array('postal_code' => '6310', 'city' => 'Broager', 'latitude' => 54.8847, 'longitude' => 9.6692),
            array('postal_code' => '6320', 'city' => 'Egernsund', 'latitude' => 54.8944, 'longitude' => 9.6044),
            array('postal_code' => '6330', 'city' => 'Padborg', 'latitude' => 54.8222, 'longitude' => 9.3600),
            array('postal_code' => '6340', 'city' => 'Kruså', 'latitude' => 54.8511, 'longitude' => 9.3994),
            array('postal_code' => '6360', 'city' => 'Tinglev', 'latitude' => 54.9411, 'longitude' => 9.2622),
            array('postal_code' => '6372', 'city' => 'Bylderup-Bov', 'latitude' => 54.9200, 'longitude' => 9.1392),
            array('postal_code' => '6392', 'city' => 'Bolderslev', 'latitude' => 55.0150, 'longitude' => 9.2633),
            array('postal_code' => '6400', 'city' => 'Sønderborg', 'latitude' => 54.9092, 'longitude' => 9.7919),
            array('postal_code' => '6430', 'city' => 'Nordborg', 'latitude' => 55.0511, 'longitude' => 9.7486),
            array('postal_code' => '6440', 'city' => 'Augustenborg', 'latitude' => 54.9489, 'longitude' => 9.8711),
            array('postal_code' => '6470', 'city' => 'Sydals', 'latitude' => 54.9050, 'longitude' => 9.6678),
            array('postal_code' => '6500', 'city' => 'Vojens', 'latitude' => 55.2472, 'longitude' => 9.3172),
            array('postal_code' => '6510', 'city' => 'Gram', 'latitude' => 55.2956, 'longitude' => 9.0583),
            array('postal_code' => '6520', 'city' => 'Toftlund', 'latitude' => 55.1783, 'longitude' => 9.0628),
            array('postal_code' => '6534', 'city' => 'Agerskov', 'latitude' => 55.1308, 'longitude' => 9.1222),
            array('postal_code' => '6535', 'city' => 'Branderup J', 'latitude' => 55.1492, 'longitude' => 9.1719),
            array('postal_code' => '6541', 'city' => 'Bevtoft', 'latitude' => 55.2108, 'longitude' => 9.2600),
            array('postal_code' => '6560', 'city' => 'Sommersted', 'latitude' => 55.3583, 'longitude' => 9.3736),
            array('postal_code' => '6580', 'city' => 'Vamdrup', 'latitude' => 55.4294, 'longitude' => 9.2839),
            array('postal_code' => '6600', 'city' => 'Vejen', 'latitude' => 55.4817, 'longitude' => 9.1394),
            array('postal_code' => '6621', 'city' => 'Gesten', 'latitude' => 55.5536, 'longitude' => 9.0300),
            array('postal_code' => '6622', 'city' => 'Bække', 'latitude' => 55.4708, 'longitude' => 9.0683),
            array('postal_code' => '6623', 'city' => 'Vorbasse', 'latitude' => 55.6117, 'longitude' => 9.1119),
            array('postal_code' => '6630', 'city' => 'Rødding', 'latitude' => 55.3667, 'longitude' => 9.0667),
            array('postal_code' => '6640', 'city' => 'Lunderskov', 'latitude' => 55.4825, 'longitude' => 9.3111),
            array('postal_code' => '6650', 'city' => 'Brørup', 'latitude' => 55.5119, 'longitude' => 9.0072),
            array('postal_code' => '6660', 'city' => 'Lintrup', 'latitude' => 55.3333, 'longitude' => 8.9833),
            array('postal_code' => '6670', 'city' => 'Holsted', 'latitude' => 55.5064, 'longitude' => 8.9192),
            array('postal_code' => '6682', 'city' => 'Hovborg', 'latitude' => 55.5978, 'longitude' => 8.9261),
            array('postal_code' => '6683', 'city' => 'Føvling', 'latitude' => 55.5611, 'longitude' => 8.8492),
            array('postal_code' => '6690', 'city' => 'Gørding', 'latitude' => 55.4986, 'longitude' => 8.7892),
            array('postal_code' => '6700', 'city' => 'Esbjerg', 'latitude' => 55.4761, 'longitude' => 8.4600),
            array('postal_code' => '6705', 'city' => 'Esbjerg Ø', 'latitude' => 55.4800, 'longitude' => 8.5000),
            array('postal_code' => '6710', 'city' => 'Esbjerg V', 'latitude' => 55.4700, 'longitude' => 8.4300),
            array('postal_code' => '6715', 'city' => 'Esbjerg N', 'latitude' => 55.5000, 'longitude' => 8.4500),
            array('postal_code' => '6720', 'city' => 'Fanø', 'latitude' => 55.4417, 'longitude' => 8.3961),
            array('postal_code' => '6731', 'city' => 'Tjæreborg', 'latitude' => 55.4700, 'longitude' => 8.5833),
            array('postal_code' => '6740', 'city' => 'Bramming', 'latitude' => 55.4667, 'longitude' => 8.7000),
            array('postal_code' => '6752', 'city' => 'Glejbjerg', 'latitude' => 55.5283, 'longitude' => 8.7944),
            array('postal_code' => '6753', 'city' => 'Agerbæk', 'latitude' => 55.5611, 'longitude' => 8.7778),
            array('postal_code' => '6760', 'city' => 'Ribe', 'latitude' => 55.3289, 'longitude' => 8.7644),
            array('postal_code' => '6771', 'city' => 'Gredstedbro', 'latitude' => 55.4508, 'longitude' => 8.7094),
            array('postal_code' => '6780', 'city' => 'Skærbæk', 'latitude' => 55.1683, 'longitude' => 8.7656),
            array('postal_code' => '6792', 'city' => 'Rømø', 'latitude' => 55.1547, 'longitude' => 8.5400),
            array('postal_code' => '6800', 'city' => 'Varde', 'latitude' => 55.6206, 'longitude' => 8.4803),
            array('postal_code' => '6818', 'city' => 'Årre', 'latitude' => 55.5061, 'longitude' => 8.4244),
            array('postal_code' => '6823', 'city' => 'Ansager', 'latitude' => 55.6800, 'longitude' => 8.6889),
            array('postal_code' => '6830', 'city' => 'Nørre Nebel', 'latitude' => 55.7822, 'longitude' => 8.2367),
            array('postal_code' => '6840', 'city' => 'Oksbøl', 'latitude' => 55.6436, 'longitude' => 8.2644),
            array('postal_code' => '6851', 'city' => 'Janderup Vestj', 'latitude' => 55.7200, 'longitude' => 8.3819),
            array('postal_code' => '6852', 'city' => 'Billum', 'latitude' => 55.6517, 'longitude' => 8.3300),
            array('postal_code' => '6853', 'city' => 'Vejers Strand', 'latitude' => 55.6533, 'longitude' => 8.1247),
            array('postal_code' => '6854', 'city' => 'Henne', 'latitude' => 55.7472, 'longitude' => 8.2261),
            array('postal_code' => '6855', 'city' => 'Outrup', 'latitude' => 55.6683, 'longitude' => 8.4889),
            array('postal_code' => '6857', 'city' => 'Blåvand', 'latitude' => 55.5639, 'longitude' => 8.0858),
            array('postal_code' => '6862', 'city' => 'Tistrup', 'latitude' => 55.7381, 'longitude' => 8.5564),
            array('postal_code' => '6870', 'city' => 'Ølgod', 'latitude' => 55.8111, 'longitude' => 8.6294),
            array('postal_code' => '6880', 'city' => 'Tarm', 'latitude' => 55.9119, 'longitude' => 8.5244),
            array('postal_code' => '6893', 'city' => 'Hemmet', 'latitude' => 55.9194, 'longitude' => 8.3319),
            array('postal_code' => '6900', 'city' => 'Skjern', 'latitude' => 55.9500, 'longitude' => 8.5000),
            array('postal_code' => '6920', 'city' => 'Videbæk', 'latitude' => 56.0869, 'longitude' => 8.6333),
            array('postal_code' => '6933', 'city' => 'Kibæk', 'latitude' => 55.9997, 'longitude' => 8.8931),
            array('postal_code' => '6940', 'city' => 'Lem St', 'latitude' => 56.0500, 'longitude' => 8.3500),
            array('postal_code' => '6950', 'city' => 'Ringkøbing', 'latitude' => 56.0900, 'longitude' => 8.2444),
            array('postal_code' => '6960', 'city' => 'Hvide Sande', 'latitude' => 56.0019, 'longitude' => 8.1294),
            array('postal_code' => '6971', 'city' => 'Spjald', 'latitude' => 56.0556, 'longitude' => 8.4453),
            array('postal_code' => '6973', 'city' => 'Ørnhøj', 'latitude' => 56.1078, 'longitude' => 8.7100),
            array('postal_code' => '6980', 'city' => 'Tim', 'latitude' => 56.0139, 'longitude' => 8.5178),
            array('postal_code' => '6990', 'city' => 'Ulfborg', 'latitude' => 56.2639, 'longitude' => 8.3233),
            array('postal_code' => '7000', 'city' => 'Fredericia', 'latitude' => 55.5653, 'longitude' => 9.7519),
            array('postal_code' => '7080', 'city' => 'Børkop', 'latitude' => 55.6531, 'longitude' => 9.6592),
            array('postal_code' => '7100', 'city' => 'Vejle', 'latitude' => 55.7094, 'longitude' => 9.5358),
            array('postal_code' => '7120', 'city' => 'Vejle Ø', 'latitude' => 55.7150, 'longitude' => 9.5700),
            array('postal_code' => '7130', 'city' => 'Juelsminde', 'latitude' => 55.7119, 'longitude' => 10.0150),
            array('postal_code' => '7140', 'city' => 'Stouby', 'latitude' => 55.7333, 'longitude' => 9.8167),
            array('postal_code' => '7150', 'city' => 'Barrit', 'latitude' => 55.6858, 'longitude' => 9.7739),
            array('postal_code' => '7160', 'city' => 'Tørring', 'latitude' => 55.8617, 'longitude' => 9.4869),
            array('postal_code' => '7171', 'city' => 'Uldum', 'latitude' => 55.8167, 'longitude' => 9.6000),
            array('postal_code' => '7173', 'city' => 'Vonge', 'latitude' => 55.8000, 'longitude' => 9.6833),
            array('postal_code' => '7182', 'city' => 'Bredsten', 'latitude' => 55.7411, 'longitude' => 9.3939),
            array('postal_code' => '7183', 'city' => 'Randbøl', 'latitude' => 55.7000, 'longitude' => 9.2667),
            array('postal_code' => '7184', 'city' => 'Vandel', 'latitude' => 55.6833, 'longitude' => 9.2167),
            array('postal_code' => '7190', 'city' => 'Billund', 'latitude' => 55.7300, 'longitude' => 9.1167),
            array('postal_code' => '7200', 'city' => 'Grindsted', 'latitude' => 55.7500, 'longitude' => 8.9333),
            array('postal_code' => '7250', 'city' => 'Hejnsvig', 'latitude' => 55.6833, 'longitude' => 9.0333),
            array('postal_code' => '7260', 'city' => 'Sønder Omme', 'latitude' => 55.8667, 'longitude' => 8.9333),
            array('postal_code' => '7270', 'city' => 'Stakroge', 'latitude' => 55.9000, 'longitude' => 8.7667),
            array('postal_code' => '7280', 'city' => 'Sønder Felding', 'latitude' => 56.0000, 'longitude' => 8.8667),
            array('postal_code' => '7300', 'city' => 'Jelling', 'latitude' => 55.7567, 'longitude' => 9.4231),
            array('postal_code' => '7321', 'city' => 'Gadbjerg', 'latitude' => 55.7833, 'longitude' => 9.3333),
            array('postal_code' => '7323', 'city' => 'Give', 'latitude' => 55.8436, 'longitude' => 9.2381),
            array('postal_code' => '7330', 'city' => 'Brande', 'latitude' => 55.9667, 'longitude' => 9.1167),
            array('postal_code' => '7361', 'city' => 'Ejstrupholm', 'latitude' => 55.9167, 'longitude' => 9.3167),
            array('postal_code' => '7362', 'city' => 'Hampen', 'latitude' => 56.0333, 'longitude' => 9.4167),
            array('postal_code' => '7400', 'city' => 'Herning', 'latitude' => 56.1364, 'longitude' => 8.9753),
            array('postal_code' => '7430', 'city' => 'Ikast', 'latitude' => 56.1383, 'longitude' => 9.1578),
            array('postal_code' => '7441', 'city' => 'Bording', 'latitude' => 56.1667, 'longitude' => 9.2500),
            array('postal_code' => '7442', 'city' => 'Engesvang', 'latitude' => 56.1000, 'longitude' => 9.3333),
            array('postal_code' => '7451', 'city' => 'Sunds', 'latitude' => 56.1833, 'longitude' => 9.0833),
            array('postal_code' => '7470', 'city' => 'Karup J', 'latitude' => 56.3072, 'longitude' => 9.1722),
            array('postal_code' => '7480', 'city' => 'Vildbjerg', 'latitude' => 56.1931, 'longitude' => 8.7608),
            array('postal_code' => '7490', 'city' => 'Aulum', 'latitude' => 56.2219, 'longitude' => 8.8664),
            array('postal_code' => '7500', 'city' => 'Holstebro', 'latitude' => 56.3600, 'longitude' => 8.6167),
            array('postal_code' => '7540', 'city' => 'Haderup', 'latitude' => 56.3333, 'longitude' => 9.0000),
            array('postal_code' => '7550', 'city' => 'Sørvad', 'latitude' => 56.3333, 'longitude' => 8.9167),
            array('postal_code' => '7560', 'city' => 'Hjerm', 'latitude' => 56.4500, 'longitude' => 8.6500),
            array('postal_code' => '7570', 'city' => 'Vemb', 'latitude' => 56.3000, 'longitude' => 8.4000),
            array('postal_code' => '7600', 'city' => 'Struer', 'latitude' => 56.4917, 'longitude' => 8.5917),
            array('postal_code' => '7620', 'city' => 'Lemvig', 'latitude' => 56.5500, 'longitude' => 8.3000),
            array('postal_code' => '7650', 'city' => 'Bøvlingbjerg', 'latitude' => 56.4833, 'longitude' => 8.3000),
            array('postal_code' => '7660', 'city' => 'Bækmarksbro', 'latitude' => 56.5500, 'longitude' => 8.5000),
            array('postal_code' => '7673', 'city' => 'Harboøre', 'latitude' => 56.6333, 'longitude' => 8.1833),
            array('postal_code' => '7680', 'city' => 'Thyborøn', 'latitude' => 56.7050, 'longitude' => 8.2153),
            array('postal_code' => '7700', 'city' => 'Thisted', 'latitude' => 56.9558, 'longitude' => 8.6961),
            array('postal_code' => '7730', 'city' => 'Hanstholm', 'latitude' => 57.1167, 'longitude' => 8.6167),
            array('postal_code' => '7741', 'city' => 'Frøstrup', 'latitude' => 57.0167, 'longitude' => 8.7833),
            array('postal_code' => '7742', 'city' => 'Vesløs', 'latitude' => 56.9667, 'longitude' => 8.6333),
            array('postal_code' => '7752', 'city' => 'Snedsted', 'latitude' => 56.8833, 'longitude' => 8.5667),
            array('postal_code' => '7755', 'city' => 'Bedsted Thy', 'latitude' => 56.8667, 'longitude' => 8.6833),
            array('postal_code' => '7760', 'city' => 'Hurup Thy', 'latitude' => 56.7333, 'longitude' => 8.4500),
            array('postal_code' => '7770', 'city' => 'Vestervig', 'latitude' => 56.7667, 'longitude' => 8.3167),
            array('postal_code' => '7790', 'city' => 'Thyholm', 'latitude' => 56.6000, 'longitude' => 8.7167),
            array('postal_code' => '7800', 'city' => 'Skive', 'latitude' => 56.5667, 'longitude' => 9.0333),
            array('postal_code' => '7830', 'city' => 'Vinderup', 'latitude' => 56.4833, 'longitude' => 8.7833),
            array('postal_code' => '7840', 'city' => 'Højslev', 'latitude' => 56.5833, 'longitude' => 9.1667),
            array('postal_code' => '7850', 'city' => 'Stoholm Jyll', 'latitude' => 56.4333, 'longitude' => 9.0500),
            array('postal_code' => '7860', 'city' => 'Spøttrup', 'latitude' => 56.6667, 'longitude' => 8.9167),
            array('postal_code' => '7870', 'city' => 'Roslev', 'latitude' => 56.7167, 'longitude' => 8.9167),
            array('postal_code' => '7884', 'city' => 'Fur', 'latitude' => 56.8333, 'longitude' => 9.0333),
            array('postal_code' => '7900', 'city' => 'Nykøbing M', 'latitude' => 56.7947, 'longitude' => 8.8619),
            array('postal_code' => '7950', 'city' => 'Erslev', 'latitude' => 56.7667, 'longitude' => 8.7667),
            array('postal_code' => '7960', 'city' => 'Karby', 'latitude' => 56.7167, 'longitude' => 8.7333),
            array('postal_code' => '7970', 'city' => 'Redsted M', 'latitude' => 56.6667, 'longitude' => 8.8167),
            array('postal_code' => '7980', 'city' => 'Vils', 'latitude' => 56.7333, 'longitude' => 8.6833),
            array('postal_code' => '7990', 'city' => 'Øster Assels', 'latitude' => 56.7000, 'longitude' => 8.7000),
            array('postal_code' => '8000', 'city' => 'Aarhus C', 'latitude' => 56.1629, 'longitude' => 10.2039),
            array('postal_code' => '8200', 'city' => 'Aarhus N', 'latitude' => 56.1847, 'longitude' => 10.1997),
            array('postal_code' => '8210', 'city' => 'Aarhus V', 'latitude' => 56.1525, 'longitude' => 10.1608),
            array('postal_code' => '8220', 'city' => 'Brabrand', 'latitude' => 56.1411, 'longitude' => 10.1175),
            array('postal_code' => '8230', 'city' => 'Åbyhøj', 'latitude' => 56.1581, 'longitude' => 10.1533),
            array('postal_code' => '8240', 'city' => 'Risskov', 'latitude' => 56.1867, 'longitude' => 10.2219),
            array('postal_code' => '8250', 'city' => 'Egå', 'latitude' => 56.2086, 'longitude' => 10.2547),
            array('postal_code' => '8260', 'city' => 'Viby J', 'latitude' => 56.1214, 'longitude' => 10.1489),
            array('postal_code' => '8270', 'city' => 'Højbjerg', 'latitude' => 56.1281, 'longitude' => 10.1983),
            array('postal_code' => '8300', 'city' => 'Odder', 'latitude' => 55.9733, 'longitude' => 10.1525),
            array('postal_code' => '8305', 'city' => 'Samsø', 'latitude' => 55.8667, 'longitude' => 10.6000),
            array('postal_code' => '8310', 'city' => 'Tranbjerg J', 'latitude' => 56.1158, 'longitude' => 10.1106),
            array('postal_code' => '8320', 'city' => 'Mårslet', 'latitude' => 56.0861, 'longitude' => 10.1700),
            array('postal_code' => '8330', 'city' => 'Beder', 'latitude' => 56.0883, 'longitude' => 10.2217),
            array('postal_code' => '8340', 'city' => 'Malling', 'latitude' => 56.0492, 'longitude' => 10.2272),
            array('postal_code' => '8350', 'city' => 'Hundslund', 'latitude' => 56.0283, 'longitude' => 10.2578),
            array('postal_code' => '8355', 'city' => 'Solbjerg', 'latitude' => 56.0139, 'longitude' => 10.2917),
            array('postal_code' => '8361', 'city' => 'Hasselager', 'latitude' => 56.1044, 'longitude' => 10.2761),
            array('postal_code' => '8362', 'city' => 'Hørning', 'latitude' => 56.1750, 'longitude' => 10.0833),
            array('postal_code' => '8370', 'city' => 'Hadsten', 'latitude' => 56.3244, 'longitude' => 10.0478),
            array('postal_code' => '8380', 'city' => 'Trige', 'latitude' => 56.2419, 'longitude' => 10.1567),
            array('postal_code' => '8381', 'city' => 'Tilst', 'latitude' => 56.1764, 'longitude' => 10.1047),
            array('postal_code' => '8382', 'city' => 'Hinnerup', 'latitude' => 56.2722, 'longitude' => 10.0542),
            array('postal_code' => '8400', 'city' => 'Ebeltoft', 'latitude' => 56.1947, 'longitude' => 10.6803),
            array('postal_code' => '8410', 'city' => 'Rønde', 'latitude' => 56.2986, 'longitude' => 10.4792),
            array('postal_code' => '8420', 'city' => 'Knebel', 'latitude' => 56.2450, 'longitude' => 10.5244),
            array('postal_code' => '8444', 'city' => 'Balle', 'latitude' => 56.3333, 'longitude' => 10.3500),
            array('postal_code' => '8450', 'city' => 'Hammel', 'latitude' => 56.2611, 'longitude' => 9.8594),
            array('postal_code' => '8462', 'city' => 'Harlev J', 'latitude' => 56.1364, 'longitude' => 10.0700),
            array('postal_code' => '8464', 'city' => 'Galten', 'latitude' => 56.1533, 'longitude' => 9.9161),
            array('postal_code' => '8471', 'city' => 'Sabro', 'latitude' => 56.2153, 'longitude' => 10.0433),
            array('postal_code' => '8472', 'city' => 'Sporup', 'latitude' => 56.2833, 'longitude' => 9.9500),
            array('postal_code' => '8500', 'city' => 'Grenaa', 'latitude' => 56.4158, 'longitude' => 10.8767),
            array('postal_code' => '8520', 'city' => 'Lystrup', 'latitude' => 56.2364, 'longitude' => 10.2297),
            array('postal_code' => '8530', 'city' => 'Hjortshøj', 'latitude' => 56.2525, 'longitude' => 10.3178),
            array('postal_code' => '8541', 'city' => 'Skødstrup', 'latitude' => 56.2761, 'longitude' => 10.2622),
            array('postal_code' => '8543', 'city' => 'Hornslet', 'latitude' => 56.3161, 'longitude' => 10.3253),
            array('postal_code' => '8544', 'city' => 'Mørke', 'latitude' => 56.3694, 'longitude' => 10.5436),
            array('postal_code' => '8550', 'city' => 'Ryomgård', 'latitude' => 56.3864, 'longitude' => 10.5000),
            array('postal_code' => '8560', 'city' => 'Kolind', 'latitude' => 56.3328, 'longitude' => 10.6133),
            array('postal_code' => '8570', 'city' => 'Trustrup', 'latitude' => 56.4500, 'longitude' => 10.7167),
            array('postal_code' => '8581', 'city' => 'Nimtofte', 'latitude' => 56.4833, 'longitude' => 10.6500),
            array('postal_code' => '8585', 'city' => 'Glesborg', 'latitude' => 56.5167, 'longitude' => 10.7333),
            array('postal_code' => '8586', 'city' => 'Ørum Djurs', 'latitude' => 56.4333, 'longitude' => 10.7667),
            array('postal_code' => '8592', 'city' => 'Anholt', 'latitude' => 56.7167, 'longitude' => 11.5500),
            array('postal_code' => '8600', 'city' => 'Silkeborg', 'latitude' => 56.1697, 'longitude' => 9.5478),
            array('postal_code' => '8620', 'city' => 'Kjellerup', 'latitude' => 56.2983, 'longitude' => 9.4311),
            array('postal_code' => '8632', 'city' => 'Lemming', 'latitude' => 56.3667, 'longitude' => 9.5167),
            array('postal_code' => '8641', 'city' => 'Sorring', 'latitude' => 56.2000, 'longitude' => 9.7167),
            array('postal_code' => '8643', 'city' => 'Ans By', 'latitude' => 56.2167, 'longitude' => 9.7833),
            array('postal_code' => '8654', 'city' => 'Bryrup', 'latitude' => 56.0333, 'longitude' => 9.4500),
            array('postal_code' => '8660', 'city' => 'Skanderborg', 'latitude' => 56.0342, 'longitude' => 9.9311),
            array('postal_code' => '8670', 'city' => 'Låsby', 'latitude' => 56.1500, 'longitude' => 9.7333),
            array('postal_code' => '8680', 'city' => 'Ry', 'latitude' => 56.0900, 'longitude' => 9.7628),
            array('postal_code' => '8700', 'city' => 'Horsens', 'latitude' => 55.8608, 'longitude' => 9.8500),
            array('postal_code' => '8721', 'city' => 'Daugård', 'latitude' => 55.8167, 'longitude' => 9.6500),
            array('postal_code' => '8722', 'city' => 'Hedensted', 'latitude' => 55.7708, 'longitude' => 9.7000),
            array('postal_code' => '8723', 'city' => 'Løsning', 'latitude' => 55.9000, 'longitude' => 9.6333),
            array('postal_code' => '8732', 'city' => 'Hovedgård', 'latitude' => 55.8667, 'longitude' => 10.0500),
            array('postal_code' => '8740', 'city' => 'Brædstrup', 'latitude' => 55.9667, 'longitude' => 9.6167),
            array('postal_code' => '8752', 'city' => 'Østbirk', 'latitude' => 55.9667, 'longitude' => 9.5167),
            array('postal_code' => '8762', 'city' => 'Flemming', 'latitude' => 55.9167, 'longitude' => 9.4667),
            array('postal_code' => '8763', 'city' => 'Rask Mølle', 'latitude' => 55.8833, 'longitude' => 9.4833),
            array('postal_code' => '8765', 'city' => 'Klovborg', 'latitude' => 55.9500, 'longitude' => 9.3667),
            array('postal_code' => '8766', 'city' => 'Nørre Snede', 'latitude' => 55.9167, 'longitude' => 9.2500),
            array('postal_code' => '8781', 'city' => 'Stenderup', 'latitude' => 55.8167, 'longitude' => 9.9500),
            array('postal_code' => '8783', 'city' => 'Hornsyld', 'latitude' => 55.7667, 'longitude' => 9.8000),
            array('postal_code' => '8800', 'city' => 'Viborg', 'latitude' => 56.4533, 'longitude' => 9.4022),
            array('postal_code' => '8830', 'city' => 'Tjele', 'latitude' => 56.4333, 'longitude' => 9.6167),
            array('postal_code' => '8840', 'city' => 'Rødkærsbro', 'latitude' => 56.2833, 'longitude' => 9.2833),
            array('postal_code' => '8850', 'city' => 'Bjerringbro', 'latitude' => 56.3811, 'longitude' => 9.6617),
            array('postal_code' => '8860', 'city' => 'Ulstrup', 'latitude' => 56.3500, 'longitude' => 9.8333),
            array('postal_code' => '8870', 'city' => 'Langå', 'latitude' => 56.3892, 'longitude' => 9.9019),
            array('postal_code' => '8881', 'city' => 'Thorsø', 'latitude' => 56.2667, 'longitude' => 9.8333),
            array('postal_code' => '8882', 'city' => 'Fårvang', 'latitude' => 56.2500, 'longitude' => 9.6167),
            array('postal_code' => '8883', 'city' => 'Gjern', 'latitude' => 56.1833, 'longitude' => 9.7000),
            array('postal_code' => '8900', 'city' => 'Randers C', 'latitude' => 56.4606, 'longitude' => 10.0361),
            array('postal_code' => '8920', 'city' => 'Randers NV', 'latitude' => 56.4900, 'longitude' => 10.0200),
            array('postal_code' => '8930', 'city' => 'Randers NØ', 'latitude' => 56.4800, 'longitude' => 10.0700),
            array('postal_code' => '8940', 'city' => 'Randers SV', 'latitude' => 56.4400, 'longitude' => 10.0200),
            array('postal_code' => '8950', 'city' => 'Ørsted', 'latitude' => 56.3833, 'longitude' => 10.2500),
            array('postal_code' => '8960', 'city' => 'Randers SØ', 'latitude' => 56.4400, 'longitude' => 10.0700),
            array('postal_code' => '8961', 'city' => 'Allingåbro', 'latitude' => 56.4978, 'longitude' => 10.3847),
            array('postal_code' => '8963', 'city' => 'Auning', 'latitude' => 56.4261, 'longitude' => 10.4525),
            array('postal_code' => '8970', 'city' => 'Havndal', 'latitude' => 56.5833, 'longitude' => 10.2167),
            array('postal_code' => '8981', 'city' => 'Spentrup', 'latitude' => 56.5333, 'longitude' => 10.0500),
            array('postal_code' => '8983', 'city' => 'Gjerlev J', 'latitude' => 56.5000, 'longitude' => 10.1667),
            array('postal_code' => '8990', 'city' => 'Fårup', 'latitude' => 56.4833, 'longitude' => 9.8667),
            array('postal_code' => '9000', 'city' => 'Aalborg', 'latitude' => 57.0488, 'longitude' => 9.9217),
            array('postal_code' => '9200', 'city' => 'Aalborg SV', 'latitude' => 57.0200, 'longitude' => 9.8700),
            array('postal_code' => '9210', 'city' => 'Aalborg SØ', 'latitude' => 57.0200, 'longitude' => 9.9700),
            array('postal_code' => '9220', 'city' => 'Aalborg Øst', 'latitude' => 57.0600, 'longitude' => 10.0000),
            array('postal_code' => '9230', 'city' => 'Svenstrup J', 'latitude' => 57.0094, 'longitude' => 10.0806),
            array('postal_code' => '9240', 'city' => 'Nibe', 'latitude' => 56.9800, 'longitude' => 9.6392),
            array('postal_code' => '9260', 'city' => 'Gistrup', 'latitude' => 56.9917, 'longitude' => 9.9611),
            array('postal_code' => '9270', 'city' => 'Klarup', 'latitude' => 57.0333, 'longitude' => 10.0667),
            array('postal_code' => '9280', 'city' => 'Storvorde', 'latitude' => 57.0667, 'longitude' => 10.1167),
            array('postal_code' => '9293', 'city' => 'Kongerslev', 'latitude' => 57.0333, 'longitude' => 10.1833),
            array('postal_code' => '9300', 'city' => 'Sæby', 'latitude' => 57.3333, 'longitude' => 10.5167),
            array('postal_code' => '9310', 'city' => 'Vodskov', 'latitude' => 57.1333, 'longitude' => 10.0333),
            array('postal_code' => '9320', 'city' => 'Hjallerup', 'latitude' => 57.1667, 'longitude' => 10.1167),
            array('postal_code' => '9330', 'city' => 'Dronninglund', 'latitude' => 57.1667, 'longitude' => 10.2833),
            array('postal_code' => '9340', 'city' => 'Asaa', 'latitude' => 57.2167, 'longitude' => 10.4000),
            array('postal_code' => '9352', 'city' => 'Dybvad', 'latitude' => 57.2500, 'longitude' => 10.3000),
            array('postal_code' => '9362', 'city' => 'Gandrup', 'latitude' => 57.0667, 'longitude' => 10.2500),
            array('postal_code' => '9370', 'city' => 'Hals', 'latitude' => 56.9997, 'longitude' => 10.3119),
            array('postal_code' => '9380', 'city' => 'Vestbjerg', 'latitude' => 57.0833, 'longitude' => 9.9000),
            array('postal_code' => '9381', 'city' => 'Sulsted', 'latitude' => 57.0833, 'longitude' => 9.8333),
            array('postal_code' => '9382', 'city' => 'Tylstrup', 'latitude' => 57.1167, 'longitude' => 9.9167),
            array('postal_code' => '9400', 'city' => 'Nørresundby', 'latitude' => 57.0597, 'longitude' => 9.9192),
            array('postal_code' => '9430', 'city' => 'Vadum', 'latitude' => 57.1167, 'longitude' => 9.8167),
            array('postal_code' => '9440', 'city' => 'Aabybro', 'latitude' => 57.1500, 'longitude' => 9.7333),
            array('postal_code' => '9460', 'city' => 'Brovst', 'latitude' => 57.0900, 'longitude' => 9.5300),
            array('postal_code' => '9480', 'city' => 'Løkken', 'latitude' => 57.3700, 'longitude' => 9.7200),
            array('postal_code' => '9490', 'city' => 'Pandrup', 'latitude' => 57.2167, 'longitude' => 9.6833),
            array('postal_code' => '9492', 'city' => 'Blokhus', 'latitude' => 57.2667, 'longitude' => 9.5833),
            array('postal_code' => '9493', 'city' => 'Saltum', 'latitude' => 57.2333, 'longitude' => 9.6500),
            array('postal_code' => '9500', 'city' => 'Hobro', 'latitude' => 56.6428, 'longitude' => 9.7906),
            array('postal_code' => '9510', 'city' => 'Arden', 'latitude' => 56.7667, 'longitude' => 9.8667),
            array('postal_code' => '9520', 'city' => 'Skørping', 'latitude' => 56.8322, 'longitude' => 9.8944),
            array('postal_code' => '9530', 'city' => 'Støvring', 'latitude' => 56.8883, 'longitude' => 9.8350),
            array('postal_code' => '9541', 'city' => 'Suldrup', 'latitude' => 56.9167, 'longitude' => 9.7500),
            array('postal_code' => '9550', 'city' => 'Mariager', 'latitude' => 56.6500, 'longitude' => 9.9750),
            array('postal_code' => '9560', 'city' => 'Hadsund', 'latitude' => 56.7167, 'longitude' => 10.1167),
            array('postal_code' => '9574', 'city' => 'Bælum', 'latitude' => 56.9167, 'longitude' => 9.9500),
            array('postal_code' => '9575', 'city' => 'Terndrup', 'latitude' => 56.8500, 'longitude' => 9.9833),
            array('postal_code' => '9600', 'city' => 'Aars', 'latitude' => 56.8028, 'longitude' => 9.5142),
            array('postal_code' => '9610', 'city' => 'Nørager', 'latitude' => 56.7000, 'longitude' => 9.6167),
            array('postal_code' => '9620', 'city' => 'Aalestrup', 'latitude' => 56.6900, 'longitude' => 9.4900),
            array('postal_code' => '9631', 'city' => 'Gedsted', 'latitude' => 56.6167, 'longitude' => 9.2833),
            array('postal_code' => '9632', 'city' => 'Møldrup', 'latitude' => 56.5667, 'longitude' => 9.4333),
            array('postal_code' => '9640', 'city' => 'Farsø', 'latitude' => 56.7733, 'longitude' => 9.3411),
            array('postal_code' => '9670', 'city' => 'Løgstør', 'latitude' => 56.9681, 'longitude' => 9.2500),
            array('postal_code' => '9681', 'city' => 'Ranum', 'latitude' => 56.8667, 'longitude' => 9.3167),
            array('postal_code' => '9690', 'city' => 'Fjerritslev', 'latitude' => 57.0900, 'longitude' => 9.2700),
            array('postal_code' => '9700', 'city' => 'Brønderslev', 'latitude' => 57.2700, 'longitude' => 9.9400),
            array('postal_code' => '9740', 'city' => 'Jerslev J', 'latitude' => 57.3333, 'longitude' => 10.0167),
            array('postal_code' => '9750', 'city' => 'Østervrå', 'latitude' => 57.3667, 'longitude' => 10.2667),
            array('postal_code' => '9760', 'city' => 'Vrå', 'latitude' => 57.3500, 'longitude' => 10.1333),
            array('postal_code' => '9800', 'city' => 'Hjørring', 'latitude' => 57.4639, 'longitude' => 9.9819),
            array('postal_code' => '9830', 'city' => 'Tårs', 'latitude' => 57.3833, 'longitude' => 9.9000),
            array('postal_code' => '9850', 'city' => 'Hirtshals', 'latitude' => 57.5939, 'longitude' => 9.9614),
            array('postal_code' => '9870', 'city' => 'Sindal', 'latitude' => 57.5000, 'longitude' => 10.2167),
            array('postal_code' => '9881', 'city' => 'Bindslev', 'latitude' => 57.5333, 'longitude' => 10.0833),
            array('postal_code' => '9900', 'city' => 'Frederikshavn', 'latitude' => 57.4408, 'longitude' => 10.5364),
            array('postal_code' => '9940', 'city' => 'Læsø', 'latitude' => 57.2753, 'longitude' => 11.0003),
            array('postal_code' => '9970', 'city' => 'Strandby', 'latitude' => 57.4900, 'longitude' => 10.5100),
            array('postal_code' => '9981', 'city' => 'Jerup', 'latitude' => 57.5667, 'longitude' => 10.3333),
            array('postal_code' => '9982', 'city' => 'Ålbæk', 'latitude' => 57.5900, 'longitude' => 10.4100),
            array('postal_code' => '9990', 'city' => 'Skagen', 'latitude' => 57.7206, 'longitude' => 10.5839),
        );
    }

    /**
     * Get postal code data by postal code
     *
     * @param string $postal_code The postal code to look up
     * @return array|null Postal code data or null if not found
     */
    public static function get_postal_code($postal_code) {
        $postal_code = trim($postal_code);
        $all_codes = self::get_all_postal_codes();

        foreach ($all_codes as $code_data) {
            if ($code_data['postal_code'] === $postal_code) {
                return $code_data;
            }
        }

        return null;
    }

    /**
     * Get coordinates for a postal code
     *
     * @param string $postal_code The postal code to look up
     * @return array|null Array with 'latitude' and 'longitude' or null if not found
     */
    public static function get_coordinates($postal_code) {
        $data = self::get_postal_code($postal_code);

        if ($data) {
            return array(
                'latitude' => $data['latitude'],
                'longitude' => $data['longitude']
            );
        }

        return null;
    }

    /**
     * Find postal codes within a certain distance from a location
     *
     * @param float $latitude Center latitude
     * @param float $longitude Center longitude
     * @param float $radius_km Radius in kilometers
     * @return array Array of postal codes within radius
     */
    public static function find_within_radius($latitude, $longitude, $radius_km) {
        $results = array();
        $all_codes = self::get_all_postal_codes();

        foreach ($all_codes as $code_data) {
            $distance = self::calculate_distance(
                $latitude,
                $longitude,
                $code_data['latitude'],
                $code_data['longitude']
            );

            if ($distance <= $radius_km) {
                $code_data['distance'] = $distance;
                $results[] = $code_data;
            }
        }

        // Sort by distance
        usort($results, function($a, $b) {
            return $a['distance'] <=> $b['distance'];
        });

        return $results;
    }

    /**
     * Calculate distance between two coordinates using Haversine formula
     *
     * @param float $lat1 Latitude of point 1
     * @param float $lon1 Longitude of point 1
     * @param float $lat2 Latitude of point 2
     * @param float $lon2 Longitude of point 2
     * @return float Distance in kilometers
     */
    public static function calculate_distance($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 6371; // km

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat/2) * sin($dLat/2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon/2) * sin($dLon/2);

        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance = $earth_radius * $c;

        return round($distance, 2);
    }

    /**
     * Find coordinates by city name (searches postal codes database)
     * Returns the first matching postal code's coordinates
     *
     * @param string $city_name City name to search for
     * @return array|null Array with 'latitude' and 'longitude' or null if not found
     */
    public static function get_coordinates_by_city($city_name) {
        $city_name = trim($city_name);
        if (empty($city_name)) {
            return null;
        }

        $all_codes = self::get_all_postal_codes();

        // Try exact match first (case-insensitive)
        foreach ($all_codes as $code_data) {
            if (strcasecmp($code_data['city'], $city_name) === 0) {
                return array(
                    'latitude' => $code_data['latitude'],
                    'longitude' => $code_data['longitude'],
                    'postal_code' => $code_data['postal_code'],
                    'city' => $code_data['city']
                );
            }
        }

        // Try partial match (case-insensitive)
        foreach ($all_codes as $code_data) {
            if (stripos($code_data['city'], $city_name) !== false) {
                return array(
                    'latitude' => $code_data['latitude'],
                    'longitude' => $code_data['longitude'],
                    'postal_code' => $code_data['postal_code'],
                    'city' => $code_data['city']
                );
            }
        }

        return null;
    }
}
