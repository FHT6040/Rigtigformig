/**
 * Rigtig for mig - Admin JavaScript
 */

(function($) {
    'use strict';
    
    // WordPress media uploader is already handled in the meta box inline script
    // This file can be used for additional admin functionality
    
    // You can add more admin-specific JavaScript here
    
})(jQuery);
