<?php
/**
 * Plugin Name: Rigtig for Mig
 * Plugin URI:  https://www.rigtigformig.dk
 * Description: Et plugin der forbinder eksperter med klienter via WordPress.
 * Version:     1.0.0
 * Author:      Frank Tessin
 * License:     GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Sikrer at filen ikke kan tilgås direkte
}

// Definer plugin-sti
define('RFM_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('RFM_PLUGIN_URL', plugin_dir_url(__FILE__));

// Inkluder nødvendige filer
require_once RFM_PLUGIN_PATH . 'includes/custom-post-types.php';
require_once RFM_PLUGIN_PATH . 'includes/shortcodes.php';
require_once RFM_PLUGIN_PATH . 'includes/admin-menu.php';
require_once RFM_PLUGIN_PATH . 'includes/registration.php';
require_once RFM_PLUGIN_PATH . 'includes/booking.php';
require_once RFM_PLUGIN_PATH . 'includes/expert-dashboard.php';
require_once RFM_PLUGIN_PATH . 'includes/login.php';
require_once RFM_PLUGIN_PATH . 'includes/bruger-dashboard.php';
require_once RFM_PLUGIN_PATH . 'includes/mine-bookinger.php';
require_once RFM_PLUGIN_PATH . 'includes/migrate-users.php';
require_once RFM_PLUGIN_PATH . 'includes/verify-email.php';



// Opret brugerroller ved aktivering
function rfm_add_custom_roles() {
    add_role(
        'expert',
        'Ekspert',
        array(
            'read'         => true,
            'edit_posts'   => true,
            'upload_files' => true,
            'publish_posts' => true
        )
    );

    add_role(
        'client',
        'Klient',
        array(
            'read' => true
        )
    );
}

register_activation_hook(__FILE__, 'rfm_add_custom_roles');


// Aktiveringsfunktion
function rfm_activate_plugin() {
    flush_rewrite_rules(); // Opdaterer permalinks
}
register_activation_hook(__FILE__, 'rfm_activate_plugin');

// Deaktiveringsfunktion
function rfm_deactivate_plugin() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'rfm_deactivate_plugin');

// Opret booking-tabel ved aktivering
function rfm_create_booking_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfm_bookings';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        expert_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        booking_date DATE NOT NULL,
        booking_time TIME NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'rfm_create_booking_table');

// Opret booking-tabel ved aktivering
function rfm_create_booking_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfm_bookings';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        expert_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        booking_date DATE NOT NULL,
        booking_time TIME NOT NULL,
        status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'rfm_create_booking_table');
