<?php get_header(); ?>

<div class="rfm-container">
    <h1>Vores eksperter</h1>
    <div class="rfm-expert-list">
        <?php
        if (have_posts()) :
            while (have_posts()) : the_post(); ?>
                <div class="rfm-expert">
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <p><?php the_excerpt(); ?></p>
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('medium'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endwhile;
        else :
            echo '<p>Ingen eksperter fundet.</p>';
        endif;
        ?>
    </div>
</div>

<?php get_footer(); ?>
