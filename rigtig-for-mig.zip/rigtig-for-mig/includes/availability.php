<?php
if (!defined('ABSPATH')) {
    exit;
}

// Shortcode: Ekspertens tilgængelige tider
function rfm_expert_availability() {
    if (!is_user_logged_in()) {
        return '<p>Du skal være logget ind. <a href="/login/">Log ind her</a></p>';
    }

    $user_id = get_current_user_id();

    ob_start();
    ?>
    <form method="post">
        <?php wp_nonce_field('rfm_availability_action', 'rfm_availability_nonce'); ?>

        <p>
            <label for="available_days">Vælg tilgængelige dage:</label><br>
            <input type="checkbox" name="available_days[]" value="monday"> Mandag
            <input type="checkbox" name="available_days[]" value="tuesday"> Tirsdag
            <input type="checkbox" name="available_days[]" value="wednesday"> Onsdag
        </p>

        <p>
            <label for="start_time">Starttid:</label>
            <input type="time" name="start_time" required>
        </p>

        <p>
            <label for="end_time">Sluttid:</label>
            <input type="time" name="end_time" required>
        </p>

        <p>
            <input type="submit" name="save_availability" value="Gem tilgængelighed">
        </p>
    </form>
    <?php
    return ob_get_clean();
}

// Håndtering af gemning af tilgængelighed
function rfm_handle_availability() {
    if (isset($_POST['save_availability'])) {

        if (!isset($_POST['rfm_availability_nonce']) || !wp_verify_nonce($_POST['rfm_availability_nonce'], 'rfm_availability_action')) {
            echo '<p>Sikkerhedsfejl. Prøv igen.</p>';
            return;
        }

        $user_id = get_current_user_id();
        $available_days = isset($_POST['available_days']) ? $_POST['available_days'] : array();
        $start_time = sanitize_text_field($_POST['start_time']);
        $end_time = sanitize_text_field($_POST['end_time']);

        update_user_meta($user_id, 'available_days', json_encode($available_days));
        update_user_meta($user_id, 'start_time', $start_time);
        update_user_meta($user_id, 'end_time', $end_time);

        echo '<p>Tilgængelighed gemt!</p>';
    }
}

add_action('init', 'rfm_handle_availability');
add_shortcode('rfm_availability', 'rfm_expert_availability');
