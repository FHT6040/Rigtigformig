<?php
if (!defined('ABSPATH')) {
    exit;
}

// Load Google API Client Library
require_once RFM_PLUGIN_PATH . 'includes/google-api/vendor/autoload.php';

// Google API-indstillinger
define('GOOGLE_CLIENT_ID', 'DIN_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'DIT_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', home_url('/ekspert-dashboard/'));

// Opret forbindelse til Google API
function rfm_get_google_client() {
    $client = new Google_Client();
    $client->setClientId(GOOGLE_CLIENT_ID);
    $client->setClientSecret(GOOGLE_CLIENT_SECRET);
    $client->setRedirectUri(GOOGLE_REDIRECT_URI);
    $client->addScope(Google_Service_Calendar::CALENDAR_EVENTS);
    $client->setAccessType('offline');
    return $client;
}

// Ekspert-forbindelse til Google Kalender
function rfm_connect_google_calendar() {
    $client = rfm_get_google_client();
    $auth_url = $client->createAuthUrl();
    return '<a href="' . esc_url($auth_url) . '">Forbind din Google Kalender</a>';
}

add_shortcode('rfm_google_calendar', 'rfm_connect_google_calendar');
