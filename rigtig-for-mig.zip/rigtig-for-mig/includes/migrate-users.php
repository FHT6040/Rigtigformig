<?php
if (!defined('ABSPATH')) {
    exit;
}

// Migration-funktion
function rfm_migrate_users_to_cpt() {
    global $wpdb;

    // Find alle brugere, der er "Ekspert" eller "Klient"
    $users = get_users(array(
        'role__in' => array('expert', 'client')
    ));

    foreach ($users as $user) {
        // Tjek om brugeren allerede er migreret
        $existing_post = get_posts(array(
            'post_type'  => array('expert', 'client'),
            'meta_query' => array(
                array(
                    'key'   => 'original_wp_user_id',
                    'value' => $user->ID
                )
            )
        ));

        if (!empty($existing_post)) {
            continue; // Skip hvis brugeren allerede er migreret
        }

        // Bestem post_type (Ekspert eller Klient)
        $post_type = in_array('expert', $user->roles) ? 'expert' : 'client';

        // Opret ny CPT post
        $post_id = wp_insert_post(array(
            'post_type'   => $post_type,
            'post_title'  => $user->display_name,
            'post_status' => 'publish',
            'meta_input'  => array(
                'email'               => $user->user_email,
                'original_wp_user_id' => $user->ID, // Så vi kan tracke migrerede brugere
            )
        ));

        if ($post_id) {
            echo "Migreret: " . esc_html($user->display_name) . " til " . esc_html($post_type) . "<br>";
        }
    }
}

// Tilføj admin-menu for migration
function rfm_add_migration_menu() {
    add_submenu_page(
        'rigtig-for-mig',
        'Migrer Brugere',
        'Migrer Brugere',
        'manage_options',
        'rfm-migrate-users',
        'rfm_migration_page'
    );
}
add_action('admin_menu', 'rfm_add_migration_menu');

// Admin-side til at køre migration
function rfm_migration_page() {
    echo "<div class='wrap'><h1>Migrer WordPress Brugere til CPT</h1>";
    echo "<p>Dette vil flytte alle eksperter og klienter over til Custom Post Types.</p>";
    echo "<form method='post'>";
    echo "<input type='submit' name='migrate_users' value='Start Migration' class='button button-primary'>";
    echo "</form>";

    if (isset($_POST['migrate_users'])) {
        rfm_migrate_users_to_cpt();
    }

    echo "</div>";
}
