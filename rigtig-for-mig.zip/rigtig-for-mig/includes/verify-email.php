<?php
if (!defined('ABSPATH')) {
    exit;
}

// Håndter e-mail-verifikation
function rfm_verify_email() {
    if (!isset($_GET['code'])) {
        return '<p>Ugyldig verifikationskode.</p>';
    }

    global $wpdb;
    $verification_code = sanitize_text_field($_GET['code']);

    // Find brugeren med denne verifikationskode
    $user_query = new WP_Query(array(
        'post_type'  => array('expert', 'client'),
        'post_status' => 'draft',
        'meta_query' => array(
            array(
                'key'   => 'verification_code',
                'value' => $verification_code
            )
        )
    ));

    if ($user_query->have_posts()) {
        $user_query->the_post();
        $user_id = get_the_ID();

        // Opdater brugerens status til "public" (aktiveret)
        wp_update_post(array(
            'ID'          => $user_id,
            'post_status' => 'publish'
        ));

        // Fjern verifikationskode og marker e-mail som verificeret
        update_post_meta($user_id, 'email_verified', true);
        delete_post_meta($user_id, 'verification_code');

        // Tjek, om det er en ekspert, og send dem til ekspert-dashboardet
        if (get_post_type($user_id) === 'expert') {
            wp_redirect(home_url('/ekspert-dashboard/'));
        } else {
            wp_redirect(home_url('/bruger-dashboard/'));
        }
        exit;
    } else {
        return '<p>Verifikationskode ikke fundet.</p>';
    }
}

// Registrér shortcode
add_shortcode('rfm_verify_email', 'rfm_verify_email');
