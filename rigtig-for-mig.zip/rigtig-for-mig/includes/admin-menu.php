<?php
if (!defined('ABSPATH')) {
    exit;
}

// Opret hovedmenu i WordPress admin
function rfm_add_admin_menu() {
    add_menu_page(
        'Rigtig for Mig',   // Sidenavn
        'Rigtig for Mig',   // Menu-navn
        'manage_options',   // Adgangsrettigheder (admin)
        'rigtig-for-mig',   // Slug
        'rfm_admin_dashboard', // Callback function
        'dashicons-admin-users', // Ikon
        25 // Placering i menuen
    );

    add_submenu_page(
        'rigtig-for-mig',
        'Eksperter',
        'Eksperter',
        'manage_options',
        'edit.php?post_type=expert'
    );

    add_submenu_page(
        'rigtig-for-mig',
        'Indstillinger',
        'Indstillinger',
        'manage_options',
        'rfm-settings',
        'rfm_admin_settings_page'
    );
}

// Dashboard side
function rfm_admin_dashboard() {
    echo "<div class='wrap'><h1>Velkommen til Rigtig for Mig</h1></div>";
}

// Indstillinger side
function rfm_admin_settings_page() {
    echo "<div class='wrap'><h1>Indstillinger</h1><p>Her kan du tilføje fremtidige indstillinger.</p></div>";
}

add_action('admin_menu', 'rfm_add_admin_menu');
