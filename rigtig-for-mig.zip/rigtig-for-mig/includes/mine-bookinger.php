<?php
if (!defined('ABSPATH')) {
    exit;
}

// Brugerens bookinger shortcode
function rfm_user_bookings() {
    if (!is_user_logged_in()) {
        return '<p>Du skal være logget ind for at se dine bookinger. <a href="/login/">Log ind her</a></p>';
    }

    global $wpdb;
    $user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'rfm_bookings';

    // Hent bookinger for den aktuelle bruger
    $bookings = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id = $user_id ORDER BY booking_date ASC");

    ob_start();
    echo '<h2>Mine Bookinger</h2>';

    if ($bookings) {
        echo '<table border="1">
                <tr>
                    <th>Ekspert</th>
                    <th>Dato</th>
                    <th>Tidspunkt</th>
                    <th>Status</th>
                </tr>';
        foreach ($bookings as $booking) {
            $expert = get_userdata($booking->expert_id);
            echo '<tr>
                    <td>' . esc_html($expert->display_name) . '</td>
                    <td>' . esc_html($booking->booking_date) . '</td>
                    <td>' . esc_html($booking->booking_time) . '</td>
                    <td>' . esc_html($booking->status) . '</td>
                  </tr>';
        }
        echo '</table>';
    } else {
        echo '<p>Du har ingen bookinger endnu.</p>';
    }

    return ob_get_clean();
}

// Registrér shortcode
add_shortcode('rfm_mine_bookinger', 'rfm_user_bookings');
