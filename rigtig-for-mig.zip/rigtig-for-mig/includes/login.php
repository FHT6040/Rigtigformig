<?php
if (!defined('ABSPATH')) {
    exit;
}

// Login-formular shortcode
function rfm_login_form() {
    if (is_user_logged_in()) {
        return '<p>Du er allerede logget ind. <a href="' . esc_url(wp_logout_url(home_url())) . '">Log ud</a></p>';
    }

    ob_start();
    ?>
    <form method="post">
        <?php wp_nonce_field('rfm_login_action', 'rfm_login_nonce'); ?>
        
        <p>
            <label for="username">Brugernavn eller E-mail:</label>
            <input type="text" name="username" required>
        </p>
        
        <p>
            <label for="password">Adgangskode:</label>
            <input type="password" name="password" required>
        </p>

        <p>
            <input type="submit" name="rfm_login" value="Log ind">
        </p>
        
        <p>Har du ikke en konto? <a href="/bliv-bruger/">Opret en her</a></p>
    </form>
    <?php
    return ob_get_clean();
}

// Håndtering af login
function rfm_handle_login() {
    if (isset($_POST['rfm_login'])) {

        // ✅ Tjek nonce
        if (!isset($_POST['rfm_login_nonce']) || !wp_verify_nonce($_POST['rfm_login_nonce'], 'rfm_login_action')) {
            echo '<p>Sikkerhedsfejl. Prøv igen.</p>';
            return;
        }

        // ✅ Tjek om felterne er udfyldt
        if (empty($_POST['username']) || empty($_POST['password'])) {
            echo '<p>Alle felter skal udfyldes.</p>';
            return;
        }

        $username = sanitize_text_field($_POST['username']);
		$password = $_POST['password'];

		// Find WordPress-bruger baseret på e-mail
		$user = get_user_by('email', $username);
		if (!$user) {
		$user = get_user_by('login', $username);
}

if (!$user) {
    echo '<p>Bruger ikke fundet.</p>';
    return;
}

// Brug WordPress' standard login-funktion
$credentials = array(
    'user_login'    => $user->user_login,
    'user_password' => $password,
    'remember'      => true
);

$user = wp_signon($credentials, false);

if (is_wp_error($user)) {
    echo '<p>Forkert brugernavn eller adgangskode.</p>';
} else {
    wp_redirect(rfm_get_redirect_url($user->ID));
    exit;
}


        $user = wp_signon($credentials, false);

        if (is_wp_error($user)) {
            echo '<p>Forkert brugernavn eller adgangskode.</p>';
        } else {
            wp_redirect(rfm_get_redirect_url($user->ID));
            exit;
        }
    }
}

add_action('init', 'rfm_handle_login');

// Find ud af, hvor brugeren skal omdirigeres efter login
function rfm_get_redirect_url($user_id) {
    $user = get_userdata($user_id);
    
    if (in_array('expert', $user->roles)) {
        return home_url('/ekspert-dashboard/');
    } else {
        return home_url('/bruger-dashboard/');
    }
}

// Registrér shortcode
$rfm_shortcodes['rfm_login'] = 'rfm_login_form';
