<?php
if (!defined('ABSPATH')) {
    exit;
}

// Registreringsformular Shortcode
function rfm_registration_form($atts) {
    $atts = shortcode_atts(array(
        'type' => 'client' // Standard er klient
    ), $atts);

    ob_start();
    ?>
    <form method="post">
        <?php wp_nonce_field('rfm_register_action', 'rfm_register_nonce'); ?>

        <p>
            <label for="name">Navn:</label>
            <input type="text" name="name" required>
        </p>

        <p>
            <label for="email">E-mail:</label>
            <input type="email" name="email" required>
        </p>

        <p>
            <label for="password">Adgangskode:</label>
            <input type="password" name="password" required>
        </p>

        <input type="hidden" name="type" value="<?php echo esc_attr($atts['type']); ?>">
        
        <p><input type="submit" name="rfm_register" value="Opret konto"></p>
    </form>
    <?php
    return ob_get_clean();
}

// Håndter registrering med e-mail-verifikation og WP-brugeroprettelse
function rfm_handle_registration() {
    if (isset($_POST['rfm_register'])) {
        if (!isset($_POST['rfm_register_nonce']) || !wp_verify_nonce($_POST['rfm_register_nonce'], 'rfm_register_action')) {
            echo '<p>Sikkerhedsfejl. Prøv igen.</p>';
            return;
        }

        if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password'])) {
            echo '<p>Alle felter skal udfyldes.</p>';
            return;
        }

        $name     = sanitize_text_field($_POST['name']);
        $email    = sanitize_email($_POST['email']);
        $password = $_POST['password']; // Skal hash'es senere
        $type     = sanitize_text_field($_POST['type']);

        $post_type = ($type === 'expert') ? 'expert' : 'client';

        // Generér en unik verifikationskode
        $verification_code = wp_generate_password(20, false);

        // Opret bruger som "kladde", indtil e-mail er bekræftet
        $post_id = wp_insert_post(array(
            'post_type'   => $post_type,
            'post_title'  => $name,
            'post_status' => 'draft', // Bruger er inaktiv, indtil e-mail er bekræftet
            'meta_input'  => array(
                'email'             => $email,
                'verification_code' => $verification_code,
                'email_verified'    => false
            )
        ));

        if ($post_id) {
            // Opret en WordPress-bruger
            $user_id = wp_create_user($email, $password, $email);
            
            if (!is_wp_error($user_id)) {
                wp_update_user(array(
                    'ID'   => $user_id,
                    'role' => ($type === 'expert') ? 'expert' : 'client'
                ));

                // Gem WP-bruger-ID i CPT
                update_post_meta($post_id, 'wp_user_id', $user_id);
            }

            // Send bekræftelses-e-mail
            $verification_link = home_url("/verificer-email/?code=$verification_code");
            $subject = "Bekræft din e-mail";
            $message = "Hej $name,\n\nKlik på linket for at bekræfte din e-mail:\n$verification_link\n\nTak!";
            wp_mail($email, $subject, $message);
            
            echo '<p>En e-mail er sendt til dig. Bekræft din e-mail for at aktivere din konto.</p>';
        } else {
            echo '<p>Der opstod en fejl. Prøv igen.</p>';
        }
    }
}

add_action('init', 'rfm_handle_registration');

// Registrér shortcodes
add_shortcode('rfm_bruger_registrering', function() {
    return rfm_registration_form(array('type' => 'client'));
});

add_shortcode('rfm_ekspert_registrering', function() {
    return rfm_registration_form(array('type' => 'expert'));
});
