<?php
if (!defined('ABSPATH')) {
    exit;
}

// Opret Custom Post Type for Eksperter
function rfm_register_expert_post_type() {
    $labels = array(
        'name'               => 'Eksperter',
        'singular_name'      => 'Ekspert',
        'menu_name'          => 'Eksperter',
        'add_new'            => 'Tilføj ny ekspert',
        'edit_item'          => 'Rediger ekspert',
        'new_item'           => 'Ny ekspert',
        'view_item'          => 'Se ekspert',
        'search_items'       => 'Søg eksperter',
        'not_found'          => 'Ingen eksperter fundet',
        'not_found_in_trash' => 'Ingen eksperter i papirkurven'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'menu_icon'          => 'dashicons-businessperson',
        'supports'           => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'rewrite'            => array('slug' => 'eksperter')
    );

    register_post_type('expert', $args);
}

// Opret Custom Post Type for Klienter
function rfm_register_client_post_type() {
    $labels = array(
        'name'               => 'Klienter',
        'singular_name'      => 'Klient',
        'menu_name'          => 'Klienter',
        'add_new'            => 'Tilføj ny klient',
        'edit_item'          => 'Rediger klient',
        'new_item'           => 'Ny klient',
        'view_item'          => 'Se klient',
        'search_items'       => 'Søg klienter',
        'not_found'          => 'Ingen klienter fundet',
        'not_found_in_trash' => 'Ingen klienter i papirkurven'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'menu_icon'          => 'dashicons-groups',
        'supports'           => array('title', 'editor', 'custom-fields'),
        'rewrite'            => array('slug' => 'klienter')
    );

    register_post_type('client', $args);
}

// Registrer begge post types
add_action('init', 'rfm_register_expert_post_type');
add_action('init', 'rfm_register_client_post_type');
