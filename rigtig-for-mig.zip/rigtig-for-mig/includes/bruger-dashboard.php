<?php
if (!defined('ABSPATH')) {
    exit;
}

// Bruger Dashboard Shortcode
function rfm_bruger_dashboard() {
    if (!is_user_logged_in()) {
        return '<p>Du skal være logget ind for at se dit dashboard. <a href="/login/">Log ind her</a></p>';
    }

    $user_id = get_current_user_id();
    $user_info = get_userdata($user_id);

    ob_start();
    ?>
    <div class="rfm-dashboard">
        <h2>Velkommen, <?php echo esc_html($user_info->display_name); ?>!</h2>
        <p>Her kan du administrere dine bookinger og profil.</p>
        
        <ul>
            <li><a href="/booking/">Se mine bookinger</a></li>
            <li><a href="<?php echo esc_url(wp_logout_url(home_url())); ?>">Log ud</a></li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}

// Registrér shortcode
add_shortcode('rfm_bruger_dashboard', 'rfm_bruger_dashboard');
