<?php
if (!defined('ABSPATH')) {
    exit;
}

// Shortcodes Array
global $rfm_shortcodes;
$rfm_shortcodes = array(
    'rfm_eksperter'            => 'rfm_expert_list_shortcode',
    'rfm_bruger_registrering'  => 'rfm_registration_form',
    'rfm_ekspert_registrering' => 'rfm_expert_registration_form',
    'rfm_booking'              => 'rfm_booking_form',  // Booking shortcode
    'rfm_expert_dashboard'     => 'rfm_expert_dashboard', // Ekspert dashboard shortcode
    'rfm_login'                => 'rfm_login_form'  // Login shortcode
);

// Separat funktion til ekspert-registrering
function rfm_expert_registration_form() {
    return rfm_registration_form(array('role' => 'expert'));
}

// Registrér shortcodes automatisk
function rfm_register_shortcodes() {
    global $rfm_shortcodes;
    foreach ($rfm_shortcodes as $tag => $function) {
        if (is_string($function) && function_exists($function)) {
            add_shortcode($tag, $function);
        } elseif ($function instanceof Closure) {
            add_shortcode($tag, $function);
        }
    }
}
add_action('init', 'rfm_register_shortcodes');

// Shortcode: Liste over eksperter
function rfm_expert_list_shortcode($atts) {
    $args = array(
        'post_type'      => 'expert',
        'posts_per_page' => 10
    );

    $query = new WP_Query($args);
    $output = '<ul class="rfm-expert-list">';

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $output .= '<li>';
            $output .= '<h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
            if (has_post_thumbnail()) {
                $output .= get_the_post_thumbnail(get_the_ID(), 'medium');
            }
            $output .= '</li>';
        }
    } else {
        $output .= '<p>Ingen eksperter fundet.</p>';
    }
    wp_reset_postdata();
    $output .= '</ul>';
    
    return $output;
}
