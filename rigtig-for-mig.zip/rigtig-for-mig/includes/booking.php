<?php
if (!defined('ABSPATH')) {
    exit;
}

// Bookingformular Shortcode
function rfm_booking_form($atts) {
    if (!is_user_logged_in()) {
        return '<p>Du skal være logget ind for at booke en tid. <a href="/login/">Log ind her</a></p>';
    }

    $expert_id = isset($_GET['expert_id']) ? intval($_GET['expert_id']) : 0;
    if ($expert_id === 0) {
        return '<p>Vælg en ekspert for at booke en tid.</p>';
    }

    ob_start();
    ?>
    <form method="post">
        <?php wp_nonce_field('rfm_booking_action', 'rfm_booking_nonce'); ?>
        <input type="hidden" name="expert_id" value="<?php echo esc_attr($expert_id); ?>">
        
        <p>
            <label for="date">Vælg dato:</label>
            <input type="date" name="date" required>
        </p>
        
        <p>
            <label for="time">Vælg tidspunkt:</label>
            <input type="time" name="time" required>
        </p>
        
        <p>
            <input type="submit" name="rfm_book" value="Book tid">
        </p>
    </form>
    <?php
    return ob_get_clean();
}

// Håndtering af booking
function rfm_handle_booking() {
    if (isset($_POST['rfm_book'])) {

        if (!isset($_POST['rfm_booking_nonce']) || !wp_verify_nonce($_POST['rfm_booking_nonce'], 'rfm_booking_action')) {
            echo '<p>Sikkerhedsfejl. Prøv igen.</p>';
            return;
        }

        if (empty($_POST['expert_id']) || empty($_POST['date']) || empty($_POST['time'])) {
            echo '<p>Alle felter skal udfyldes.</p>';
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'rfm_bookings';

        $expert_id = intval($_POST['expert_id']);
        $user_id = get_current_user_id();
        $booking_date = sanitize_text_field($_POST['date']);
        $booking_time = sanitize_text_field($_POST['time']);

        $wpdb->insert($table_name, array(
            'expert_id' => $expert_id,
            'user_id' => $user_id,
            'booking_date' => $booking_date,
            'booking_time' => $booking_time,
            'status' => 'pending'
        ));
		
		// Send e-mail til eksperten
$expert = get_userdata($expert_id);
$user = get_userdata($user_id);
$subject = "Ny booking fra " . esc_html($user->display_name);
$message = "Hej " . esc_html($expert->display_name) . ",\n\n"
         . esc_html($user->display_name) . " har booket en session med dig.\n"
         . "Dato: " . esc_html($booking_date) . "\n"
         . "Tidspunkt: " . esc_html($booking_time) . "\n\n"
         . "Log ind her for at acceptere eller afvise: " . home_url('/ekspert-dashboard/') . "\n\n"
         . "Mvh, Second to None";

wp_mail($expert->user_email, $subject, $message);


        echo '<p>Booking sendt! Du får en bekræftelse snarest.</p>';
    }
}

add_action('init', 'rfm_handle_booking');

// Registrer shortcode
add_shortcode('rfm_booking', 'rfm_booking_form');
