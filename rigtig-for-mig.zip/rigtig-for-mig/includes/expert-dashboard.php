<?php
if (!defined('ABSPATH')) {
    exit;
}

// Ekspert Dashboard Shortcode
function rfm_expert_dashboard() {
    if (!is_user_logged_in()) {
        return '<p>Du skal være logget ind. <a href="/login/">Log ind her</a></p>';
    }

    $user_id = get_current_user_id();
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfm_bookings';

    // Håndter booking-godkendelser
    if (isset($_POST['accept_booking'])) {
        $booking_id = intval($_POST['booking_id']);
        $wpdb->update($table_name, array('status' => 'confirmed'), array('id' => $booking_id));

        // Hent booking-info
        $booking = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $booking_id");
        $client = get_userdata($booking->user_id);

        // Send e-mail til brugeren
        $subject = "Din booking er bekræftet!";
        $message = "Hej " . esc_html($client->display_name) . ",\n\n"
                 . "Din booking med " . esc_html(get_the_title($booking->expert_id)) . " er bekræftet!\n"
                 . "Dato: " . esc_html($booking->booking_date) . "\n"
                 . "Tidspunkt: " . esc_html($booking->booking_time) . "\n\n"
                 . "Mvh, Second to None";

        wp_mail($client->user_email, $subject, $message);
        echo '<p>Booking bekræftet, og e-mail sendt til ' . esc_html($client->display_name) . '.</p>';
    }

    if (isset($_POST['cancel_booking'])) {
        $booking_id = intval($_POST['booking_id']);
        $wpdb->update($table_name, array('status' => 'cancelled'), array('id' => $booking_id));

        // Hent booking-info
        $booking = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $booking_id");
        $client = get_userdata($booking->user_id);

        // Send e-mail til brugeren
        $subject = "Din booking er aflyst";
        $message = "Hej " . esc_html($client->display_name) . ",\n\n"
                 . "Din booking med " . esc_html(get_the_title($booking->expert_id)) . " er blevet aflyst.\n"
                 . "Dato: " . esc_html($booking->booking_date) . "\n"
                 . "Tidspunkt: " . esc_html($booking->booking_time) . "\n\n"
                 . "Mvh, Second to None";

        wp_mail($client->user_email, $subject, $message);
        echo '<p>Booking aflyst, og e-mail sendt til ' . esc_html($client->display_name) . '.</p>';
    }

    // Hent bookinger for denne ekspert
    $bookings = $wpdb->get_results("SELECT * FROM $table_name WHERE expert_id = $user_id ORDER BY booking_date ASC");

    ob_start();
    echo '<h2>Mine Bookinger</h2>';

    if ($bookings) {
        echo '<table border="1">
                <tr>
                    <th>Bruger</th>
                    <th>Dato</th>
                    <th>Tidspunkt</th>
                    <th>Status</th>
                    <th>Handling</th>
                </tr>';
        foreach ($bookings as $booking) {
            $client = get_userdata($booking->user_id);
            echo '<tr>
                    <td>' . esc_html($client->display_name) . '</td>
                    <td>' . esc_html($booking->booking_date) . '</td>
                    <td>' . esc_html($booking->booking_time) . '</td>
                    <td>' . esc_html($booking->status) . '</td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="booking_id" value="' . esc_attr($booking->id) . '">
                            <input type="submit" name="accept_booking" value="Accepter">
                            <input type="submit" name="cancel_booking" value="Aflys">
                        </form>
                    </td>
                  </tr>';
        }
        echo '</table>';
    } else {
        echo '<p>Ingen bookinger endnu.</p>';
    }

    return ob_get_clean();
}

add_shortcode('rfm_expert_dashboard', 'rfm_expert_dashboard');
