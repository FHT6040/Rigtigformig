<?php
/**
 * Plugin Name: Rigtig for mig - Ekspert Markedsplads
 * Plugin URI: https://rigtigformig.dk
 * Description: En komplet markedsplads for terapeuter, coaches, mentorer og vejledere med profilsider, ratings, abonnementer og multi-language support.
 * Version: 3.7.3
 * Author: Rigtig for mig
 * Author URI: https://rigtigformig.dk
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: rigtig-for-mig
 * Domain Path: /languages
 * Author: Frank H.
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('RFM_VERSION', '3.7.3');
define('RFM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RFM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RFM_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Debug mode - only enable in development
define('RFM_DEBUG', defined('WP_DEBUG') && WP_DEBUG);

/**
 * CRITICAL: Disable LiteSpeed Cache for RFM AJAX requests
 * This must run BEFORE any other code to prevent caching
 * 
 * @since 3.7.3
 */
if (defined('DOING_AJAX') && DOING_AJAX) {
    // Check if this is an RFM AJAX action
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
    if (strpos($action, 'rfm_') === 0) {
        // Tell LiteSpeed to NOT cache this request
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        if (!defined('LSCACHE_NO_CACHE')) {
            define('LSCACHE_NO_CACHE', true);
        }
        if (!defined('LITESPEED_DISABLE_ALL')) {
            define('LITESPEED_DISABLE_ALL', true);
        }
        // Also set headers early
        if (!headers_sent()) {
            header('X-LiteSpeed-Cache-Control: no-cache');
            header('Cache-Control: no-cache, no-store, must-revalidate, private');
        }
    }
}

/**
 * Hook into LiteSpeed Cache to prevent caching of RFM AJAX requests
 * This uses LiteSpeed's official API hooks
 * 
 * @since 3.7.3
 */
add_action('litespeed_control_finalize', function() {
    if (defined('DOING_AJAX') && DOING_AJAX) {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
        if (strpos($action, 'rfm_') === 0) {
            do_action('litespeed_control_set_nocache', 'RFM AJAX: ' . $action);
            do_action('litespeed_control_set_private', 'RFM AJAX: ' . $action);
        }
    }
});

/**
 * Helper function for conditional logging
 * Only logs when RFM_DEBUG is true
 *
 * @param string $message Log message
 */
function rfm_log($message) {
    if (RFM_DEBUG) {
        error_log('RFM: ' . $message);
    }
}

/**
 * Main Plugin Class
 */
class Rigtig_For_Mig {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        // Core classes
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-post-types.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-taxonomies.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-database.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-migration.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-upload-manager.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-email-verification.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-subscriptions.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-ratings.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-profile.php';

        // Expert system - Refactored modular classes (v3.5.0+)
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-authentication.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-registration.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-dashboard.php'; // Phase 2.1 (v3.6.0)
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-profile-editor.php'; // Phase 2.2 (v3.6.0)
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-expert-role-manager.php'; // Phase 2.3 (v3.6.0)

        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-flexible-fields.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-bulk-import.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-password-reset.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-online-status.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-category-profiles.php';
        
        // User system classes
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-user-registration.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-user-dashboard.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-contact-protection.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-debug-helper.php';

        // Admin classes
        require_once RFM_PLUGIN_DIR . 'admin/class-rfm-admin.php';
        require_once RFM_PLUGIN_DIR . 'admin/class-rfm-admin-settings.php';
        require_once RFM_PLUGIN_DIR . 'admin/class-rfm-user-admin.php';
        require_once RFM_PLUGIN_DIR . 'admin/class-rfm-migration-admin.php';
        
        if (is_admin()) {
            // Additional admin-only code can go here
        }
        
        // Public classes
        require_once RFM_PLUGIN_DIR . 'public/class-rfm-public.php';
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-shortcodes.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Initialize components
        add_action('init', array($this, 'init_components'));
        
        // CRITICAL: Initialize AJAX handlers early for AJAX requests
        // This ensures handlers are available before WordPress processes the AJAX action
        if (defined('DOING_AJAX') && DOING_AJAX) {
            add_action('plugins_loaded', array($this, 'init_ajax_handlers'), 1);
        }
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_public_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }
    
    /**
     * Initialize AJAX handlers early
     * Called on plugins_loaded with priority 1 for AJAX requests
     * 
     * @since 3.7.3
     */
    public function init_ajax_handlers() {
        // Only initialize the classes needed for AJAX
        RFM_User_Dashboard::get_instance();
        RFM_Expert_Dashboard::get_instance();
        RFM_Expert_Authentication::get_instance();
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('RFM: AJAX handlers initialized early via plugins_loaded');
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create custom tables
        RFM_Database::create_tables();
        
        // Register post types and taxonomies
        RFM_Post_Types::register();
        RFM_Taxonomies::register();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set default options
        $this->set_default_options();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Set default plugin options
     */
    private function set_default_options() {
        $defaults = array(
            'rfm_free_features' => array(
                'basic_profile',
                'single_category',
                'basic_listing'
            ),
            'rfm_standard_price' => 219,
            'rfm_standard_features' => array(
                'enhanced_profile',
                'multiple_categories',
                'featured_badge',
                'basic_analytics'
            ),
            'rfm_premium_price' => 399,
            'rfm_premium_features' => array(
                'premium_profile',
                'unlimited_categories',
                'top_placement',
                'advanced_analytics',
                'priority_support'
            ),
            'rfm_currency' => 'DKK',
            'rfm_email_verification' => true
        );
        
        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }
    
    /**
     * Load text domain for translations
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'rigtig-for-mig',
            false,
            dirname(RFM_PLUGIN_BASENAME) . '/languages/'
        );
    }
    
    /**
     * Initialize plugin components
     */
    public function init_components() {
        // Register post types and taxonomies
        RFM_Post_Types::register();
        RFM_Taxonomies::register();
        
        // Initialize other components
        RFM_Email_Verification::get_instance();
        RFM_Subscriptions::get_instance();
        RFM_Ratings::get_instance();
        RFM_Expert_Profile::get_instance();
        RFM_Shortcodes::get_instance();

        // Expert system - Refactored modular classes (v3.5.0+)
        RFM_Expert_Authentication::get_instance();
        RFM_Expert_Registration::get_instance();
        RFM_Expert_Dashboard::get_instance(); // Phase 2.1 (v3.6.0)
        RFM_Expert_Profile_Editor::get_instance(); // Phase 2.2 (v3.6.0)
        RFM_Expert_Role_Manager::get_instance(); // Phase 2.3 (v3.6.0)

        RFM_Flexible_Fields_System::get_instance();
        RFM_Password_Reset::get_instance();
        RFM_Online_Status::get_instance();
        RFM_Category_Profiles::get_instance();
        
        // Initialize user system
        RFM_User_Registration::get_instance();
        RFM_User_Dashboard::get_instance();
        RFM_Contact_Protection::get_instance();

        // Initialize debug helper (only when WP_DEBUG is enabled)
        RFM_Debug_Helper::get_instance();

        // Initialize upload manager (v3.4.0)
        RFM_Upload_Manager::get_instance();
        
        // Initialize bulk import (admin only)
        if (is_admin()) {
            RFM_Bulk_Import::init();
        }
        
        // Initialize admin settings
        RFM_Admin_Settings::init();
        
        // Register Elementor widgets if Elementor is active
        add_action('elementor/widgets/register', array($this, 'register_elementor_widgets'));
        
        if (is_admin()) {
            RFM_Admin::get_instance();
            RFM_User_Admin::get_instance();
        } else {
            RFM_Public::get_instance();
        }
    }
    
    /**
     * Register Elementor widgets
     */
    public function register_elementor_widgets($widgets_manager) {
        require_once RFM_PLUGIN_DIR . 'includes/class-rfm-elementor-widget.php';
        $widgets_manager->register(new RFM_Elementor_Expert_Widget());
    }
    
    /**
     * Enqueue public assets
     */
    public function enqueue_public_assets() {
        // Note: Public assets are now enqueued by RFM_Public class
        // This method is kept for backwards compatibility and can be used for global assets
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        wp_enqueue_style(
            'rfm-admin-styles',
            RFM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            RFM_VERSION
        );
        
        wp_enqueue_script(
            'rfm-admin-scripts',
            RFM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            RFM_VERSION,
            true
        );
    }
}

/**
 * Initialize the plugin
 */
function rfm_init() {
    return Rigtig_For_Mig::get_instance();
}

/**
 * CRITICAL: Initialize AJAX handlers immediately
 * This must happen BEFORE WordPress processes the AJAX action
 * 
 * @since 3.7.3
 */
function rfm_init_ajax_handlers() {
    // Only run for AJAX requests
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        return;
    }
    
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
    
    // Only initialize for RFM actions
    if (strpos($action, 'rfm_') !== 0) {
        return;
    }
    
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('RFM: Initializing AJAX handlers for action: ' . $action);
    }
    
    // Initialize the classes that handle AJAX
    RFM_User_Dashboard::get_instance();
    RFM_Expert_Dashboard::get_instance();
    RFM_Expert_Authentication::get_instance();
}

// Initialize AJAX handlers on plugins_loaded with highest priority
add_action('plugins_loaded', 'rfm_init_ajax_handlers', 0);

/**
 * Fallback AJAX handler for user profile update
 * This is registered directly in case the class-based handler fails
 * 
 * @since 3.7.3
 */
function rfm_fallback_update_user_profile() {
    // Ensure we're in an AJAX context
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        return;
    }
    
    // Set proper content type
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
    }
    
    // Debug log
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('RFM Fallback: Profile update handler called');
    }
    
    // Verify nonce
    $nonce = isset($_POST['rfm_user_nonce']) ? sanitize_text_field($_POST['rfm_user_nonce']) : '';
    if (empty($nonce) || !wp_verify_nonce($nonce, 'rfm_user_dashboard')) {
        wp_send_json_error(array('message' => 'Sikkerhedstjek fejlede. Genindlæs siden.'), 403);
        exit;
    }
    
    // Check login
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Du skal være logget ind.'), 401);
        exit;
    }
    
    $user_id = get_current_user_id();
    $display_name = isset($_POST['display_name']) ? sanitize_text_field($_POST['display_name']) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $bio = isset($_POST['bio']) ? sanitize_textarea_field($_POST['bio']) : '';
    
    if (empty($display_name)) {
        wp_send_json_error(array('message' => 'Visningsnavn er påkrævet.'));
        exit;
    }
    
    // Update user
    $result = wp_update_user(array('ID' => $user_id, 'display_name' => $display_name));
    
    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => 'Kunne ikke opdatere profil.'));
        exit;
    }
    
    update_user_meta($user_id, '_rfm_phone', $phone);
    update_user_meta($user_id, '_rfm_bio', $bio);
    
    wp_send_json_success(array('message' => '✅ Din profil er opdateret!'));
    exit;
}

// Register fallback handler with high priority (low number = runs first)
add_action('wp_ajax_rfm_update_user_profile', 'rfm_fallback_update_user_profile', 1);

/**
 * Plugin activation
 */
function rfm_activate() {
    // Create database tables
    require_once RFM_PLUGIN_DIR . 'includes/class-rfm-database.php';
    RFM_Database::create_tables();
    
    // Register post types and taxonomies
    require_once RFM_PLUGIN_DIR . 'includes/class-rfm-post-types.php';
    require_once RFM_PLUGIN_DIR . 'includes/class-rfm-taxonomies.php';
    RFM_Post_Types::register();
    RFM_Taxonomies::register();
    
    // Create expert user role
    rfm_create_expert_role();
    
    // Create regular user role
    rfm_create_user_role();
    
    // Flush rewrite rules
    flush_rewrite_rules();
}

/**
 * Create expert user role
 */
function rfm_create_expert_role() {
    // Remove role first to ensure clean registration
    remove_role('rfm_expert_user');
    
    // Add role with capabilities
    add_role(
        'rfm_expert_user',
        __('Ekspert', 'rigtig-for-mig'),
        array(
            'read' => true,
            'edit_posts' => true,
            'edit_published_posts' => true,
            'delete_posts' => false,
            'upload_files' => true,
        )
    );
}

/**
 * Create regular user role
 */
function rfm_create_user_role() {
    // Remove role first to ensure clean registration
    remove_role('rfm_user');
    
    // Add role with capabilities
    add_role(
        'rfm_user',
        __('Bruger', 'rigtig-for-mig'),
        array(
            'read' => true,
        )
    );
}

/**
 * Plugin deactivation
 */
function rfm_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
}

// Register hooks
register_activation_hook(__FILE__, 'rfm_activate');
register_deactivation_hook(__FILE__, 'rfm_deactivate');

// Start the plugin
rfm_init();
